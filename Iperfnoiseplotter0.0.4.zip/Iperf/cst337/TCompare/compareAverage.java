package TCompare;
/**
 * Write a description of class compareAverage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.io.*;
import com.googlecode.charts4j.bchart;

public class compareAverage
{
    public static void compare () throws Exception
    {
        FileReader eastfr = new FileReader( "Eastserverfilename.txt" );
        BufferedReader eastbr = new BufferedReader( eastfr );
        
        FileReader westfr = new FileReader( "Westserverfilename.txt" );
        BufferedReader westbr = new BufferedReader( westfr );
        
        FileWriter eastfw = new FileWriter( "EastBetterThanWestBy.txt" );
        BufferedWriter eastbw = new BufferedWriter( eastfw );
        
        FileWriter westfw = new FileWriter( "WestBetterThanEastBy.txt" );
        BufferedWriter westbw = new BufferedWriter( westfw );
        
        double eastValue;
        double westValue;
        String eastInput;
        String westInput;
        
        //Reads both values and stores the greater one into the appropriate file. If they are equal it is ignored.
        while( ( ( eastInput = eastbr.readLine() ) != null ) && ( ( westInput = westbr.readLine() ) != null) )
        {
            eastValue = Double.parseDouble( eastInput );
            westValue = Double.parseDouble( westInput );
            
            if( eastValue > westValue )
            {
                eastbw.write( Double.toString( eastValue - westValue ) );
                eastbw.newLine();
            }
            else if( westValue > eastValue )
            {
                westbw.write( Double.toString( westValue - eastValue ) );
                westbw.newLine();
            }
        }
        
        bchart barchart = new bchart();
        barchart.graph();
        
        eastbw.close();
        westbw.close();
        eastbr.close();
        westbr.close();
    }
}
