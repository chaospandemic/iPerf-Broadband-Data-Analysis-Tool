package iperfnoise;
/**
 * This method is the core of the program, it pulls out the ten second data and calculates the noise on the fly 
 * and prints it to a new file
 * 
 * @author Donald Willis
 * @version 0.0.2
 */
import java.io.*;
import java.math.BigDecimal;

public class process
{
    public static void data(String filename) throws Exception
    {
        FileReader fr = new FileReader("input\\" + filename);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\noise" + filename);
        BufferedWriter bw = new BufferedWriter(fw);

        double median = 0.00f;
        double max = 0.00f;
        String lineString = null;
        Integer counter = 1;
        
        while((lineString= br.readLine())!= null){
            if(counter<10){
                if (counter.equals(5))
                {
                    median = Double.parseDouble(lineString);
                    //System.out.println(median);
                }
                
                counter++;
            }
            else{
                if (counter.equals(10))
                {
                    max = Double.parseDouble(lineString);
                    //System.out.println(max);
                }
                counter = 1; 
                //this is where the median noise rate can be calculated and printed to file
                BigDecimal bd = new BigDecimal((max-median) / max);
                bd = bd.setScale(4, BigDecimal.ROUND_HALF_UP);
                
                bw.write(" "+ bd.doubleValue());
                bw.newLine();
            }
        }
        bw.close();
        fw.close();
        preparecdf.graph(filename);
    }
}
