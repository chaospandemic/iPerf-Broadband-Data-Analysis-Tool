package TCompare;
/**
 * Write a description of class averageThroughput here.
 * 
 * @author Donald Willis & Mike Fowler
 * @version 0.0.2
 */

import java.io.*;

public class averageThroughput
{
  public static void main(String[] args) throws Exception
    {
        System.out.println ("Average Comparator Application is running");
        
        // this set of commands reads in a service provider from the user and outputs it to a file 
        InputStreamReader varname = new InputStreamReader(System.in) ;
        BufferedReader provider = new BufferedReader(varname) ;
        FileWriter fw = new FileWriter ("sp.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        try {
               System.out.println("Please Enter The Service Provider To Be Processed: ");
               bw.write(provider.readLine());
          }
          catch (IOException err) {
               System.out.println("Error reading line");
          }
          bw.close();
          fw.close();
        //--------------------------------------------
        
        FileReader fr = new FileReader("filenames.txt"); //this opens up a file named filename.txt
        BufferedReader br = new BufferedReader(fr);
        Boolean stream = true;
        String filename = null;
        Boolean exist = false; //Used to show if the while loop has run more than once. Acts as a flag when opening the files
        
        while((filename= br.readLine())!= null)
        {
           averager.averager(filename, exist, stream);
           exist = true;
           stream = false;
        }
        stream = true;
        compareAverage.compare(stream);
        stream = false;
        compareAverage.compare(stream);
        stream = true;
        compareResults.results(stream);
        stream = false;
        compareResults.results(stream);
        
        System.out.println ("Program is Complete.");
    }
}
