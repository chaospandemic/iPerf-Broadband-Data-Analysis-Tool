package TCompare;
/**
 * Write a description of class averager here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.io.*;

public class averager
{
    public static void averager( String filename, Boolean exist, Boolean stream) throws Exception{
        Boolean count = true;
        double total = 0;
        double num;
        int test = 0;
        int test2=0;
        int test3=0;
        String input = null;
        String append;
        if (stream)
        {
            append = "upload.txt";
        }
        else 
        {
            append = "download.txt";
        }
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        //exist is passed to open for append mode if we have already written some values in the files from a previous loop
        FileWriter eastfw = new FileWriter("Eastserver" + append, exist);
        FileWriter westfw = new FileWriter("Westserver" + append, exist);
        BufferedWriter eastbw = new BufferedWriter(eastfw);
        BufferedWriter westbw = new BufferedWriter(westfw);
        int counter=1;
        
        while ( (input = br.readLine()) != null )
        {
            
            if(input.equals("flag"))
            {
                while((input= br.readLine())!= null && input.equals("flag"))
                {
                }
                //System.out.println(counter);
                total /= counter;
                counter = 1;
                //count acts as a switching variable flag to determine which file we need to write to
                if ( count )
                {
                    eastbw.write( Double.toString(total) );
                    eastbw.newLine();
                    count = false;
                    test++;
                }
                else
                {
                    westbw.write( Double.toString(total) );
                    westbw.newLine();
                    count = true;
                    test2++;
                }
                total = 0;
                
            }
            else
            {
                num = Double.parseDouble( input );
                total += num;
                counter++;
                test3++;
            }
            
            

        }
        eastbw.close();
        westbw.close();
        br.close();
        
        System.out.println("east with "+ test +" values");
         System.out.println("west with "+ test2 +" values");
          System.out.println("total is "+ test3 +" values");
    }
        
}
