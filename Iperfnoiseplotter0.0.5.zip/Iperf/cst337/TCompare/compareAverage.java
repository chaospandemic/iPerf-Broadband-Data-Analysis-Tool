package TCompare;
/**
 * Write a description of class compareAverage here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.io.*;


public class compareAverage
{
    public static void compare (Boolean stream) throws Exception
    {
        String labels[] = new String [3];
        String append;
        if (stream)
        {
            append = "upload.txt";
            labels[1] = "Upload";
        }
        else
        {
            append = "download.txt";
            labels[1] = "Download";
        }
        FileReader eastfr = new FileReader( "Eastserver" + append );
        BufferedReader eastbr = new BufferedReader( eastfr );

        FileReader westfr = new FileReader( "Westserver" + append );
        BufferedReader westbr = new BufferedReader( westfr );

        FileWriter eastfw = new FileWriter( "EastBetterThanWestBy" + append );
        BufferedWriter eastbw = new BufferedWriter( eastfw );

        FileWriter westfw = new FileWriter( "WestBetterThanEastBy" + append );
        BufferedWriter westbw = new BufferedWriter( westfw );

        double eastValue;
        double westValue;
        String eastInput;
        String westInput;
        int test = 0;
        int test2 = 0;
        int test3 = 0;
        //Reads both values and stores the greater one into the appropriate file. If they are equal it is ignored.
        while( ( ( eastInput = eastbr.readLine() ) != null ) && ( ( westInput = westbr.readLine() ) != null) )
        {
            eastValue = Double.parseDouble( eastInput );
            westValue = Double.parseDouble( westInput );
            test3++;
            if( eastValue > westValue )
            {
                eastbw.write( Double.toString( eastValue - westValue ) );
                eastbw.newLine();
                test++;
            }
            else if( westValue > eastValue )
            {
                westbw.write( Double.toString( westValue - eastValue ) );
                westbw.newLine();
                test2++;
            }
        }
        
        System.out.println("east is better with "+ test +" values");
         System.out.println("west is better with "+ test2 +" values");
          System.out.println("total is "+ test3 +" values");
         
        eastbw.close();
        westbw.close();
        eastbr.close();
        westbr.close();

        FileReader cr = new FileReader("sp.txt");
        BufferedReader dr = new BufferedReader(cr);

        
        

        labels[0] = dr.readLine();
        dr.close();
        cr.close();
        String filename;
        
        //open buffered readers for the files
        for (int i=0; i!=2; i++)
        {
            if (i == 0)
            {
                labels[2] = "East Better Than West";
                graph.chart("EastBetterThanWestBy" + append, labels);
                
            }
            else
            {
                labels[2] = "West Better Than East";
                graph.chart("WestBetterThanEastBy" + append, labels);
                
            }

        }
    }
}
