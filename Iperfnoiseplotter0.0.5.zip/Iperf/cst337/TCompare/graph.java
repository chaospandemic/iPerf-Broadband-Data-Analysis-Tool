package TCompare;

import java.io.*;
import com.googlecode.charts4j.bchart;

/**
 * Write a description of class graph here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class graph
{

    public static void chart(String filename, String labels[])throws Exception
    {
        FileReader fr = new FileReader(filename);
        BufferedReader br = new BufferedReader(fr);
        int counter = 0;
        double compare;
        int array[] = new int [11];
        String f;
        //System.out.println(labels[0]);
        for(int x=0; x<11; x++)
        {
            array[x] = 0;
        }
        while((f= br.readLine())!= null){ //this loop reads in

            compare = Double.parseDouble(f);
            //System.out.println(compare);
            
            if (compare < 1)
            {
                array[0]++;
            }
            else if (compare <= 100)
            {
                array[1]++;
            }
            else if (compare <= 200)
            {
                array[2]++;
            }
            else if (compare <= 300)
            {
                array[3]++;
            }
            else if (compare <= 400)
            {
                array[4]++;
            }
            else if (compare <= 500)
            {
                array[5]++;
            }
            else if (compare <= 600)
            {
                array[6]++;
            }
            else if (compare <= 700)
            {
                array[7]++;
            }
            else if (compare <= 800)
            {
                array[8]++;
            }
            else if (compare <= 900)
            {
                array[9]++;
            }
            else
            {
                array[10]++;
            }            
        }

        for(int x=0; x<11; x++)
        {
            System.out.println(array[x]);
            if (array[x] > 4000)
            {
                array[x] = 100;
            }
            else
                array[x]*=.025;
        }
        
        bchart cdf = new bchart();
        cdf.graph(array,labels);
    }
}
