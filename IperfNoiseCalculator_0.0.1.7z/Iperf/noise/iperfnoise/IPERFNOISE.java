package iperfnoise;
/**
 * This is the main function for the Iperf noise calculation
 * 
 * @author Donald Willis 
 * @version 0.0.1
 */
import java.io.*;
public class IPERFNOISE
{
    public static void main(String[] args) throws Exception
    {
        System.out.println ("Starting the Iperf on Wireless Noise Calculator 0.0.1");
        System.out.println ("Author: Donald Willis\n\n");
        
        
        FileReader fr = new FileReader("filenames.txt");
        BufferedReader br = new BufferedReader(fr);
        String filename = null;
        int counter = 1;
        while((filename= br.readLine())!= null){
            System.out.println ("Starting to parse file " + counter);
            counter++;
            process.data(filename);
            System.out.println ("Done.");
        }
    }
}
