package iperfnoise;

import com.googlecode.charts4j.CDF;

/**
 * Write a description of class preparecdf here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class preparecdf
{
   public static void graph (String filename)throws Exception{
       
       Sort sort = new Sort();
       sort.it(filename);
       
       //once its sorted, we can read the file into an array, keep track of the #of values in the array
       //we will need a way to set the range being plotted.
       //find your grouping points and how many values are there
       //we will need to multiply the # of values of the groups by mutliplied .15 to allow it to plot correctly on the graph .15 may need to be adjusted at some point depending on the results
       //an array will be passed with the noise rates, and array with the range to be plotted
       
      
       double[] array = new double[11];
       for (int i = 0; i < 11; i++)
       {
           if (i < 3)
           {
          array[i] = ((Math.tan(30*i*Math.PI/180)*10 + 50)*i/20)+30;
        }
          else
          {
              array[i] = ((Math.sin(30*i*Math.PI/180)*10 + 50)*i/20)*3;
            }
        }
       
       CDF cdf = new CDF();
       cdf.plotter(array);
       
    }
}
