package iperfprocess;
import java.io.*;
//this is used to pass text filenames
import java.util.Scanner;
//this is used for our regular expressions
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *
 * on test case for parse, files: 1476 were reported by the program
 * 1477 files were actually present
 * 1475 lat/longitudes were printed
 * not all test cases data was Good iperf data.
 * May need to look into this further.
 *
 * @author Donald Willis 
 * @version 1.0
 */
public class location
{
    public static void attparse () throws Exception{

        FileReader fr = new FileReader("att.txt");
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\location.txt");
        BufferedWriter bw = new BufferedWriter(fw);

        String filename = null;
        String lineString = null;
        int x = 0;
        Boolean failsafe = false;   //this ensures that only one data point is printed per test
        Boolean failed = false;     ///this checks if a test case failed
        System.out.println("Pulling location data for AT&T:");
        

        while((filename= br.readLine())!= null){

            FileReader fr2 = new FileReader("attbashed//" + filename);
            BufferedReader br2 = new BufferedReader(fr2);
            do
            {
                while ((lineString=br2.readLine()) != null && failed != true){
                    if (lineString.equals("no effective service") || lineString.equals("ERROR: CONNECT ERROR") || lineString.equals("ERROR: WRITE ERROR"))
                    {
                        //System.out.println(lineString);
                        x++;
                        failed = true;
                    }
                    
                }
                if (failed.equals(true))
                {         
                    filename= br.readLine();
                    failed = false;
                }
            } while (failed != false);
            
            br2.close();
            fr2.close();
            if (filename != null)
            {
                fr2 = new FileReader("attbashed//" + filename);
                br2 = new BufferedReader(fr2);

                while((lineString= br2.readLine())!= null && failsafe != true){

                    Pattern pattern = 
                        Pattern.compile("(\\d{4}), \\d{2}/\\d{2}/\\d{4},.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher .matches()){

                        failsafe = true;
                        bw.write(matcher.group(1));
                        bw.newLine();
                    }

                    //System.out.println ("iteration: " + x);
                }
                failsafe = false;

            }   
        }
        System.out.println("Failed tests: " + x);
        bw.close();
        fw.close();
        System.out.println("Done.");

    }

    public static void attcompile (String SP) throws Exception{
        FileReader fr = new FileReader("output\\location.txt");
        BufferedReader location = new BufferedReader(fr);
        FileReader fr2 = new FileReader("output\\noiseattdownloaddata.txt");
        BufferedReader download = new BufferedReader(fr2);
        FileReader fr3 = new FileReader("output\\noiseattuploaddata.txt");
        BufferedReader upload = new BufferedReader(fr3);

        FileWriter fw = new FileWriter("output\\attuploadlocationdata.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter fw2 = new FileWriter("output\\attdownloadlocationdata.csv");
        BufferedWriter bw2 = new BufferedWriter(fw2);
        
        
        bw.write(SP + " Upload Noise Rates");
        bw.newLine();
        bw.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw.newLine();
        String data = null;
        int x = 1;
        while((data= location.readLine())!= null){
            bw.write(data + ",");

            data= upload.readLine();                                    
            bw.write(data + ",");

            data= upload.readLine();   
            bw.write(data + ",");

            data= upload.readLine();            
            bw.write(data + ",");

            data= upload.readLine();
            bw.write(data + ",");
            bw.newLine();

        }
        
        location.close();
        fr.close();
        
        //.................................................................
        
        fr = new FileReader("output\\location.txt");
        location = new BufferedReader(fr);
        
        bw2.write(SP + " Download Noise Rates");
        bw2.newLine();
        bw2.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw2.newLine();
        data = null;
        x = 1;
        while((data= location.readLine())!= null){
            bw2.write(data + ",");

            data= download.readLine();                                    
            bw2.write(data + ",");

            data= download.readLine();   
            bw2.write(data + ",");

            data= download.readLine();            
            bw2.write(data + ",");

            data= download.readLine();
            bw2.write(data + ",");
            bw2.newLine();
            
        }
        
        location.close();
        
        upload.close();
        
        download.close();
        
        bw.close();
        bw2.close();
    }
    
    
    
    public static void sprintparse () throws Exception{

        FileReader fr = new FileReader("sprint.txt");
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\location.txt");
        BufferedWriter bw = new BufferedWriter(fw);

        String filename = null;
        String lineString = null;
        int x = 0;
        Boolean failsafe = false;   //this ensures that only one data point is printed per test
        Boolean failed = false;     ///this checks if a test case failed
        System.out.println("Pulling location data for Sprint:");
        

        while((filename= br.readLine())!= null){

            FileReader fr2 = new FileReader("sprintbashed//" + filename);
            BufferedReader br2 = new BufferedReader(fr2);
            do
            {
                while ((lineString=br2.readLine()) != null && failed != true){
                    if (lineString.equals("no effective service") || lineString.equals("ERROR: CONNECT ERROR") || lineString.equals("ERROR: WRITE ERROR"))
                    {
                        //System.out.println(lineString);
                        x++;
                        failed = true;
                    }
                    
                }
                if (failed.equals(true))
                {         
                    filename= br.readLine();
                    failed = false;
                }
            } while (failed != false);
            
            br2.close();
            fr2.close();
            if (filename != null)
            {
                fr2 = new FileReader("sprintbashed//" + filename);
                br2 = new BufferedReader(fr2);

                while((lineString= br2.readLine())!= null && failsafe != true){

                    Pattern pattern = 
                        Pattern.compile("(\\d{4}), \\d{2}/\\d{2}/\\d{4},.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher .matches()){

                        failsafe = true;
                        bw.write(matcher.group(1));
                        bw.newLine();
                    }

                    //System.out.println ("iteration: " + x);
                }
                failsafe = false;

            }   
        }
        System.out.println("Failed tests: " + x);
        bw.close();
        fw.close();
        System.out.println("Done.");

    }

    public static void sprintcompile (String SP) throws Exception{
        FileReader fr = new FileReader("output\\location.txt");
        BufferedReader location = new BufferedReader(fr);
        FileReader fr2 = new FileReader("output\\noisesprintdownloaddata.txt");
        BufferedReader download = new BufferedReader(fr2);
        FileReader fr3 = new FileReader("output\\noisesprintuploaddata.txt");
        BufferedReader upload = new BufferedReader(fr3);

        FileWriter fw = new FileWriter("output\\sprintuploadlocationdata.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter fw2 = new FileWriter("output\\sprintdownloadlocationdata.csv");
        BufferedWriter bw2 = new BufferedWriter(fw2);
        
        
        bw.write(SP + " Upload Noise Rates");
        bw.newLine();
        bw.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw.newLine();
        String data = null;
        int x = 1;
        while((data= location.readLine())!= null){
            bw.write(data + ",");

            data= upload.readLine();                                    
            bw.write(data + ",");

            data= upload.readLine();   
            bw.write(data + ",");

            data= upload.readLine();            
            bw.write(data + ",");

            data= upload.readLine();
            bw.write(data + ",");
            bw.newLine();

        }
        
        location.close();
        fr.close();
        
        //.................................................................
        
        fr = new FileReader("output\\location.txt");
        location = new BufferedReader(fr);
        
        bw2.write(SP + " Download Noise Rates");
        bw2.newLine();
        bw2.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw2.newLine();
        data = null;
        x = 1;
        while((data= location.readLine())!= null){
            bw2.write(data + ",");

            data= download.readLine();                                    
            bw2.write(data + ",");

            data= download.readLine();   
            bw2.write(data + ",");

            data= download.readLine();            
            bw2.write(data + ",");

            data= download.readLine();
            bw2.write(data + ",");
            bw2.newLine();
            
        }
        
        location.close();
        
        upload.close();
        
        download.close();
        
        bw.close();
        bw2.close();
    }
    
    
    
    public static void tmobileparse () throws Exception{

        FileReader fr = new FileReader("tmobile.txt");
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\location.txt");
        BufferedWriter bw = new BufferedWriter(fw);

        String filename = null;
        String lineString = null;
        int x = 0;
        Boolean failsafe = false;   //this ensures that only one data point is printed per test
        Boolean failed = false;     ///this checks if a test case failed
        System.out.println("Pulling location data for T-Mobile:");
        

        while((filename= br.readLine())!= null){

            FileReader fr2 = new FileReader("tmobilebashed//" + filename);
            BufferedReader br2 = new BufferedReader(fr2);
            do
            {
                while ((lineString=br2.readLine()) != null && failed != true){
                    if (lineString.equals("no effective service") || lineString.equals("ERROR: CONNECT ERROR") || lineString.equals("ERROR: WRITE ERROR"))
                    {
                        //System.out.println(lineString);
                        x++;
                        failed = true;
                    }
                    
                }
                if (failed.equals(true))
                {         
                    filename= br.readLine();
                    failed = false;
                }
            } while (failed != false);
            
            br2.close();
            fr2.close();
            if (filename != null)
            {
                fr2 = new FileReader("tmobilebashed//" + filename);
                br2 = new BufferedReader(fr2);

                while((lineString= br2.readLine())!= null && failsafe != true){

                    Pattern pattern = 
                        Pattern.compile("(\\d{4}), \\d{2}/\\d{2}/\\d{4},.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher .matches()){

                        failsafe = true;
                        bw.write(matcher.group(1));
                        bw.newLine();
                    }

                    //System.out.println ("iteration: " + x);
                }
                failsafe = false;

            }   
        }
        System.out.println("Failed tests: " + x);
        bw.close();
        fw.close();
        System.out.println("Done.");

    }

    public static void tmobilecompile (String SP) throws Exception{
        FileReader fr = new FileReader("output\\location.txt");
        BufferedReader location = new BufferedReader(fr);
        FileReader fr2 = new FileReader("output\\noisetmobiledownloaddata.txt");
        BufferedReader download = new BufferedReader(fr2);
        FileReader fr3 = new FileReader("output\\noisetmobileuploaddata.txt");
        BufferedReader upload = new BufferedReader(fr3);

        FileWriter fw = new FileWriter("output\\tmobileuploadlocationdata.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter fw2 = new FileWriter("output\\tmobiledownloadlocationdata.csv");
        BufferedWriter bw2 = new BufferedWriter(fw2);
        
        
        bw.write(SP + " Upload Noise Rates");
        bw.newLine();
        bw.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw.newLine();
        String data = null;
        int x = 1;
        while((data= location.readLine())!= null){
            bw.write(data + ",");

            data= upload.readLine();                                    
            bw.write(data + ",");

            data= upload.readLine();   
            bw.write(data + ",");

            data= upload.readLine();            
            bw.write(data + ",");

            data= upload.readLine();
            bw.write(data + ",");
            bw.newLine();

        }
        
        location.close();
        fr.close();
        
        //.................................................................
        
        fr = new FileReader("output\\location.txt");
        location = new BufferedReader(fr);
        
        bw2.write(SP + " Download Noise Rates");
        bw2.newLine();
        bw2.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw2.newLine();
        data = null;
        x = 1;
        while((data= location.readLine())!= null){
            bw2.write(data + ",");

            data= download.readLine();                                    
            bw2.write(data + ",");

            data= download.readLine();   
            bw2.write(data + ",");

            data= download.readLine();            
            bw2.write(data + ",");

            data= download.readLine();
            bw2.write(data + ",");
            bw2.newLine();
            
        }
        
        location.close();
        
        upload.close();
        
        download.close();
        
        bw.close();
        bw2.close();
    }
    
    
    
    public static void verizonparse () throws Exception{

        FileReader fr = new FileReader("verizon.txt");
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\location.txt");
        BufferedWriter bw = new BufferedWriter(fw);

        String filename = null;
        String lineString = null;
        int x = 0;
        Boolean failsafe = false;   //this ensures that only one data point is printed per test
        Boolean failed = false;     ///this checks if a test case failed
        System.out.println("Pulling location data for Verizon:");
        

        while((filename= br.readLine())!= null){

            FileReader fr2 = new FileReader("verizonbashed//" + filename);
            BufferedReader br2 = new BufferedReader(fr2);
            do
            {
                while ((lineString=br2.readLine()) != null && failed != true){
                    if (lineString.equals("no effective service") || lineString.equals("ERROR: CONNECT ERROR") || lineString.equals("ERROR: WRITE ERROR"))
                    {
                        //System.out.println(lineString);
                        x++;
                        failed = true;
                    }
                    
                }
                if (failed.equals(true))
                {         
                    filename= br.readLine();
                    failed = false;
                }
            } while (failed != false);
            
            br2.close();
            fr2.close();
            if (filename != null)
            {
                fr2 = new FileReader("verizonbashed//" + filename);
                br2 = new BufferedReader(fr2);

                while((lineString= br2.readLine())!= null && failsafe != true){

                    Pattern pattern = 
                        Pattern.compile("(\\d{4}), \\d{2}/\\d{2}/\\d{4},.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher .matches()){

                        failsafe = true;
                        bw.write(matcher.group(1));
                        bw.newLine();
                    }

                    //System.out.println ("iteration: " + x);
                }
                failsafe = false;

            }   
        }
        System.out.println("Failed tests: " + x);
        bw.close();
        fw.close();
        System.out.println("Done.");

    }

    public static void verizoncompile (String SP) throws Exception{
        FileReader fr = new FileReader("output\\location.txt");
        BufferedReader location = new BufferedReader(fr);
        FileReader fr2 = new FileReader("output\\noiseverizondownloaddata.txt");
        BufferedReader download = new BufferedReader(fr2);
        FileReader fr3 = new FileReader("output\\noiseverizonuploaddata.txt");
        BufferedReader upload = new BufferedReader(fr3);

        FileWriter fw = new FileWriter("output\\verizonuploadlocationdata.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter fw2 = new FileWriter("output\\verizondownloadlocationdata.csv");
        BufferedWriter bw2 = new BufferedWriter(fw2);
        
        
        bw.write(SP + " Upload Noise Rates");
        bw.newLine();
        bw.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw.newLine();
        String data = null;
        int x = 1;
        while((data= location.readLine())!= null){
            bw.write(data + ",");

            data= upload.readLine();                                    
            bw.write(data + ",");

            data= upload.readLine();   
            bw.write(data + ",");

            data= upload.readLine();            
            bw.write(data + ",");

            data= upload.readLine();
            bw.write(data + ",");
            bw.newLine();

        }
        
        location.close();
        fr.close();
        
        //.................................................................
        
        fr = new FileReader("output\\location.txt");
        location = new BufferedReader(fr);
        
        bw2.write(SP + " Download Noise Rates");
        bw2.newLine();
        bw2.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw2.newLine();
        data = null;
        x = 1;
        while((data= location.readLine())!= null){
            bw2.write(data + ",");

            data= download.readLine();                                    
            bw2.write(data + ",");

            data= download.readLine();   
            bw2.write(data + ",");

            data= download.readLine();            
            bw2.write(data + ",");

            data= download.readLine();
            bw2.write(data + ",");
            bw2.newLine();
            
        }
        
        location.close();
        
        upload.close();
        
        download.close();
        
        bw.close();
        bw2.close();
    }
}