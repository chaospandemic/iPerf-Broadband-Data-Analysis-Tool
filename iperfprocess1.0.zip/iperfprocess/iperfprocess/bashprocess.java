package iperfprocess;
import java.io.*;
/**
 * Write a description of class testor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bashprocess
{
    public static void process () throws Exception{
        //getting sprint filenames
        try{
        Process p = Runtime.getRuntime().exec("c:/iperfprocess/getbash.bat");
        p.waitFor();
    }
    catch(Exception exc)
    {
        System.out.println(exc);
    }
        //opening filenames
        FileReader fr = new FileReader("sprint.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;

        FileWriter fbat = new FileWriter("process.bat");
        BufferedWriter bbat = new BufferedWriter(fbat);
        bbat.write("@echo");
        bbat.newLine();
        int counter =1;

        while((filename= br.readLine())!= null){            
            String cmd = "cd /cygdrive/c/iperfprocess/sprint";
            String cmd2 = "bash each_sec_extract.bash " + filename + " > " + "sprintbashed/" + filename;

            try {
                bbat.write("c:/cygwin/bin/bash -li");
                bbat.write(" each_sec_extract.bash c:/iperfprocess/sprint/" + filename + " > c:/iperfprocess/sprintbashed/" + filename);
                bbat.newLine();
                bbat.write("echo File " + counter + " is complete");
                bbat.newLine();
                counter++;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }

        
        fr = new FileReader("verizon.txt");
        br = new BufferedReader(fr);
        while((filename= br.readLine())!= null){            

            try {
                bbat.write("c:/cygwin/bin/bash -li");
                bbat.write(" each_sec_extract.bash c:/iperfprocess/verizon/" + filename + " > c:/iperfprocess/verizonbashed/" + filename);
                bbat.newLine();
                bbat.write("echo File " + counter + " is complete");
                bbat.newLine();
                counter++;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }

        
        fr = new FileReader("att.txt");
        br = new BufferedReader(fr);
        while((filename= br.readLine())!= null){            

            try {
                bbat.write("c:/cygwin/bin/bash -li");
                bbat.write(" each_sec_extract.bash c:/iperfprocess/att/" + filename + " > c:/iperfprocess/attbashed/" + filename);
                bbat.newLine();
                bbat.write("echo File " + counter + " is complete");
                bbat.newLine();
                counter++;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }

        
        fr = new FileReader("tmobile.txt");
        br = new BufferedReader(fr);
        while((filename= br.readLine())!= null){            

            try {
                bbat.write("c:/cygwin/bin/bash -li");
                bbat.write(" each_sec_extract.bash c:/iperfprocess/tmobile/" + filename + " > c:/iperfprocess/tmobilebashed/" + filename);
                bbat.newLine();
                bbat.write("echo File " + counter + " is complete");
                bbat.newLine();
                counter++;
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
        bbat.close();
        fbat.close();

    }    

}

