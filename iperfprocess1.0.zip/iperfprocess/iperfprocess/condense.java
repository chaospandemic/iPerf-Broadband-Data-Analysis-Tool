package iperfprocess;
import java.io.*;
import java.util.Scanner;

/**
 * Write a description of class condense here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class condense
{
    public static void attdata() throws Exception
    { 
        Scanner s = new Scanner(new BufferedReader(new FileReader("att.txt")));
        String filename = "nothing";
        FileWriter ffw = new FileWriter("condensed/attuploaddata.txt");
        BufferedWriter fbw = new BufferedWriter(ffw);
        FileWriter f2fw = new FileWriter("condensed/attdownloaddata.txt");
        BufferedWriter f2bw = new BufferedWriter(f2fw);
        FileWriter pfr = new FileWriter("attparsedfilenames.txt");
        BufferedWriter pbr = new BufferedWriter (pfr);
        pbr.write("attuploaddata.txt");
        pbr.newLine();
        pbr.write("attdownloaddata.txt");
        pbr.newLine();
        pbr.close();
        while (s.hasNext()) {
            filename = s.next();

            FileReader fr = new FileReader("temp/att/upload" + filename);
            BufferedReader br = new BufferedReader(fr);
            FileReader dfr = new FileReader("temp/att/download" + filename);
            BufferedReader dbr = new BufferedReader(dfr);

            String lineString = null;
            
            while((lineString= br.readLine())!= null)
            {
                fbw.write(lineString);
                fbw.newLine();
                
            }
            while((lineString= dbr.readLine())!= null)
            {
                f2bw.write(lineString);
                f2bw.newLine();
            }
            
        }
        f2bw.close();
        f2fw.close();
        fbw.close();
        ffw.close();
    }
    
    
    
        public static void sprintdata() throws Exception
    { 
        Scanner s = new Scanner(new BufferedReader(new FileReader("sprint.txt")));
        String filename = "nothing";
        FileWriter ffw = new FileWriter("condensed/sprintuploaddata.txt");
        BufferedWriter fbw = new BufferedWriter(ffw);
        FileWriter f2fw = new FileWriter("condensed/sprintdownloaddata.txt");
        BufferedWriter f2bw = new BufferedWriter(f2fw);
        FileWriter pfr = new FileWriter("sprintparsedfilenames.txt");
        BufferedWriter pbr = new BufferedWriter (pfr);
        pbr.write("sprintuploaddata.txt");
        pbr.newLine();
        pbr.write("sprintdownloaddata.txt");
        pbr.newLine();
        pbr.close();
        while (s.hasNext()) {
            filename = s.next();

            FileReader fr = new FileReader("temp/sprint/upload" + filename);
            BufferedReader br = new BufferedReader(fr);
            FileReader dfr = new FileReader("temp/sprint/download" + filename);
            BufferedReader dbr = new BufferedReader(dfr);

            String lineString = null;
            
            while((lineString= br.readLine())!= null)
            {
                fbw.write(lineString);
                fbw.newLine();
                
            }
            while((lineString= dbr.readLine())!= null)
            {
                f2bw.write(lineString);
                f2bw.newLine();
            }
            
        }
        f2bw.close();
        f2fw.close();
        fbw.close();
        ffw.close();
    }


    
        public static void tmobiledata() throws Exception
    { 
        Scanner s = new Scanner(new BufferedReader(new FileReader("tmobile.txt")));
        String filename = "nothing";
        FileWriter ffw = new FileWriter("condensed/tmobileuploaddata.txt");
        BufferedWriter fbw = new BufferedWriter(ffw);
        FileWriter f2fw = new FileWriter("condensed/tmobiledownloaddata.txt");
        BufferedWriter f2bw = new BufferedWriter(f2fw);
        FileWriter pfr = new FileWriter("tmobileparsedfilenames.txt");
        BufferedWriter pbr = new BufferedWriter (pfr);
        pbr.write("tmobileuploaddata.txt");
        pbr.newLine();
        pbr.write("tmobiledownloaddata.txt");
        pbr.newLine();
        pbr.close();
        while (s.hasNext()) {
            filename = s.next();

            FileReader fr = new FileReader("temp/tmobile/upload" + filename);
            BufferedReader br = new BufferedReader(fr);
            FileReader dfr = new FileReader("temp/tmobile/download" + filename);
            BufferedReader dbr = new BufferedReader(dfr);

            String lineString = null;
            
            while((lineString= br.readLine())!= null)
            {
                fbw.write(lineString);
                fbw.newLine();
                
            }
            while((lineString= dbr.readLine())!= null)
            {
                f2bw.write(lineString);
                f2bw.newLine();
            }
            
        }
        f2bw.close();
        f2fw.close();
        fbw.close();
        ffw.close();
    }

    
    
        public static void verizondata() throws Exception
    { 
        Scanner s = new Scanner(new BufferedReader(new FileReader("verizon.txt")));
        String filename = "nothing";
        FileWriter ffw = new FileWriter("condensed/verizonuploaddata.txt");
        BufferedWriter fbw = new BufferedWriter(ffw);
        FileWriter f2fw = new FileWriter("condensed/verizondownloaddata.txt");
        BufferedWriter f2bw = new BufferedWriter(f2fw);
        FileWriter pfr = new FileWriter("verizonparsedfilenames.txt");
        BufferedWriter pbr = new BufferedWriter (pfr);
        pbr.write("verizonuploaddata.txt");
        pbr.newLine();
        pbr.write("verizondownloaddata.txt");
        pbr.newLine();
        pbr.close();
        while (s.hasNext()) {
            filename = s.next();

            FileReader fr = new FileReader("temp/verizon/upload" + filename);
            BufferedReader br = new BufferedReader(fr);
            FileReader dfr = new FileReader("temp/verizon/download" + filename);
            BufferedReader dbr = new BufferedReader(dfr);

            String lineString = null;
            
            while((lineString= br.readLine())!= null)
            {
                fbw.write(lineString);
                fbw.newLine();
                
            }
            while((lineString= dbr.readLine())!= null)
            {
                f2bw.write(lineString);
                f2bw.newLine();
            }
            
        }
        f2bw.close();
        f2fw.close();
        fbw.close();
        ffw.close();
    }
}
