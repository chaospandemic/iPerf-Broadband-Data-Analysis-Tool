package iperfprocess;
import java.io.File;
import org.apache.commons.io.FileUtils;

/**
 * Write a description of class testmkdir here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class temp
{
    public static void mkdirs()
    {
        new File("c:/iperfprocess/errors/att/noservice").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/lte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/att/phone/nonlte/writeerror").mkdirs();

        new File("c:/iperfprocess/errors/att/netbook/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/att/netbook/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/att/netbook/nonlte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/att/netbook/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/att/netbook/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/att/netbook/lte/writeerror").mkdirs();



        new File("c:/iperfprocess/errors/verizon/noservice").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/lte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/verizon/phone/nonlte/writeerror").mkdirs();

        new File("c:/iperfprocess/errors/verizon/netbook/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/netbook/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/verizon/netbook/nonlte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/netbook/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/verizon/netbook/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/verizon/netbook/lte/writeerror").mkdirs();



        new File("c:/iperfprocess/errors/tmobile/noservice").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/lte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/phone/nonlte/writeerror").mkdirs();

        new File("c:/iperfprocess/errors/tmobile/netbook/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/netbook/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/netbook/nonlte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/netbook/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/netbook/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/tmobile/netbook/lte/writeerror").mkdirs();



        new File("c:/iperfprocess/errors/sprint/noservice").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/lte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/sprint/phone/nonlte/writeerror").mkdirs();

        new File("c:/iperfprocess/errors/sprint/netbook/nonlte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/netbook/nonlte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/sprint/netbook/nonlte/writeerror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/netbook/lte/connecterror").mkdirs();
        new File("c:/iperfprocess/errors/sprint/netbook/lte/timeout").mkdirs();
        new File("c:/iperfprocess/errors/sprint/netbook/lte/writeerror").mkdirs();
    }

    public static void deldirs()
    {
        try{
            FileUtils.deleteDirectory(new File("c:/iperfprocess/errors/"));
        }
        catch(Exception exc)
        {
            System.out.println("unable to delete all error case temporary files");
        }
		try{
			FileUtils.cleanDirectory(new File("c:/iperfprocess/iperfraw/"));

            FileUtils.cleanDirectory(new File("c:/iperfprocess/att/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/sprint/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/tmobile/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/verizon/"));

			FileUtils.cleanDirectory(new File("c:/iperfprocess/attbashed/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/sprintbashed/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/tmobilebashed/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/verizonbashed/"));

			FileUtils.cleanDirectory(new File("c:/iperfprocess/temp/att/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/temp/sprint/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/temp/tmobile/"));
			FileUtils.cleanDirectory(new File("c:/iperfprocess/temp/verizon/"));
        }
        catch(Exception exc)
        {
            System.out.println("unable to delete all noise rate temporary files");
        }
    }

}
