package iperfprocess;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class SeparateData here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nLTE
{
    public static void netbookatt () throws Exception{
        //System.out.println("Looking for LTE files");
        //the following code runs a regex to look if a LTE was used
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/att/netbook/netbooklte.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/att/netbook/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/att/netbookfiles.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/att/netbook/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*netbook.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*LTE.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Netbook LTE Files");
            System.out.println(debug2 + " Netbook Non-LTE Files");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/att/netbook/netbooklte.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/att/netbook/" +filename);
                File bfile =new File("errors/att/netbook/lte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

        
        
        
        
        //the rest of this code copies the NONLTE files into the input folder
        //REPEAT THIS IS FOR NON LTE FILES
        
        //System.out.println("Moving NON LTE files");
        
        fr = new FileReader("errors/att/netbook/leftover.txt");
        br = new BufferedReader(fr);

        filename = null;
        counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/att/netbook/" +filename);
                File bfile =new File("errors/att/netbook/nonlte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    } 
    
   



public static void netbooksprint () throws Exception{
        //System.out.println("Looking for LTE files");
        //the following code runs a regex to look if a LTE was used
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/sprint/netbook/netbooklte.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/sprint/netbook/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/sprint/netbookfiles.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/sprint/netbook/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*netbook.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*LTE.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Netbook LTE Files");
            System.out.println(debug2 + " Netbook Non-LTE Files");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/sprint/netbook/netbooklte.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/sprint/netbook/" +filename);
                File bfile =new File("errors/sprint/netbook/lte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

        
        
        
        
        //the rest of this code copies the NONLTE files into the input folder
        //REPEAT THIS IS FOR NON LTE FILES
        
        //System.out.println("Moving NON LTE files");
        
        fr = new FileReader("errors/sprint/netbook/leftover.txt");
        br = new BufferedReader(fr);

        filename = null;
        counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/sprint/netbook/" +filename);
                File bfile =new File("errors/sprint/netbook/nonlte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }






public static void netbooktmobile () throws Exception{
        //System.out.println("Looking for LTE files");
        //the following code runs a regex to look if a LTE was used
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/tmobile/netbook/netbooklte.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/tmobile/netbook/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/tmobile/netbookfiles.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/tmobile/netbook/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*netbook.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*LTE.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Netbook LTE Files");
            System.out.println(debug2 + " Netbook Non-LTE Files");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/tmobile/netbook/netbooklte.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/tmobile/netbook/" +filename);
                File bfile =new File("errors/tmobile/netbook/lte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

        
        
        
        
        //the rest of this code copies the NONLTE files into the input folder
        //REPEAT THIS IS FOR NON LTE FILES
        
        //System.out.println("Moving NON LTE files");
        
        fr = new FileReader("errors/tmobile/netbook/leftover.txt");
        br = new BufferedReader(fr);

        filename = null;
        counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/tmobile/netbook/" +filename);
                File bfile =new File("errors/tmobile/netbook/nonlte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }






public static void netbookverizon () throws Exception{
        //System.out.println("Looking for LTE files");
        //the following code runs a regex to look if a LTE was used
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/verizon/netbook/netbooklte.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/verizon/netbook/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/verizon/netbookfiles.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/verizon/netbook/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*netbook.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*LTE.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Netbook LTE Files");
            System.out.println(debug2 + " Netbook Non-LTE Files");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/verizon/netbook/netbooklte.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/verizon/netbook/" +filename);
                File bfile =new File("errors/verizon/netbook/lte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

        
        
        
        
        //the rest of this code copies the NONLTE files into the input folder
        //REPEAT THIS IS FOR NON LTE FILES
        
        //System.out.println("Moving NON LTE files");
        
        fr = new FileReader("errors/verizon/netbook/leftover.txt");
        br = new BufferedReader(fr);

        filename = null;
        counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/verizon/netbook/" +filename);
                File bfile =new File("errors/verizon/netbook/nonlte/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }
}