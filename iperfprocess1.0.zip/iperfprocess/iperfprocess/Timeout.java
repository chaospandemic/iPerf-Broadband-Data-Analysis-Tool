package iperfprocess;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class SeparateData here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Timeout
{
    public static void ltetimeoutatt () throws Exception{
        //System.out.println("Looking for LTE Timeout files");
        //the following code runs a regex to look if a LTE timeout occurred
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/att/phone/lte/ltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/att/phone/lte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/att/phone/phonelte.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/att/phone/lte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/att/phone/lte/ltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/att/phone/lte/" +filename);
                File bfile =new File("errors/att/phone/lte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

    } 
    
    //
    //
    //Next Function
    //
    //
    
    public static void nonltetimeoutatt () throws Exception{
        //System.out.println("Looking for NON LTE Timeout files");
        //the following code runs a regex to look if a timeout occured
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/att/phone/nonlte/nonltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/att/phone/nonlte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/att/phone/leftover.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/att/phone/nonlte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Non-LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        //catch(Exception exc)
        //{
        //    System.out.println("unable to move one or more non lte files");
        //}
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the NONLTE timeout files into the timeout folder
        FileReader fr = new FileReader("errors/att/phone/nonlte/nonltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/att/phone/nonlte/" +filename);
                File bfile =new File("errors/att/phone/nonlte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);
                    
                }
                //outStream.flush(); //just added this...
                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }





public static void ltetimeoutsprint () throws Exception{
        //System.out.println("Looking for LTE Timeout files");
        //the following code runs a regex to look if a LTE timeout occurred
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/sprint/phone/lte/ltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/sprint/phone/lte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/sprint/phone/phonelte.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/sprint/phone/lte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/sprint/phone/lte/ltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/sprint/phone/lte/" +filename);
                File bfile =new File("errors/sprint/phone/lte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

    } 
    
    //
    //
    //Next Function
    //
    //
    
    public static void nonltetimeoutsprint () throws Exception{
        //System.out.println("Looking for NON LTE Timeout files");
        //the following code runs a regex to look if a timeout occured
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/sprint/phone/nonlte/nonltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/sprint/phone/nonlte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/sprint/phone/leftover.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/sprint/phone/nonlte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Non-LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        //catch(Exception exc)
        //{
        //    System.out.println("unable to move one or more non lte files");
        //}
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the NONLTE timeout files into the timeout folder
        FileReader fr = new FileReader("errors/sprint/phone/nonlte/nonltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/sprint/phone/nonlte/" +filename);
                File bfile =new File("errors/sprint/phone/nonlte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);
                    
                }
                //outStream.flush(); //just added this...
                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }





public static void ltetimeouttmobile () throws Exception{
        //System.out.println("Looking for LTE Timeout files");
        //the following code runs a regex to look if a LTE timeout occurred
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/tmobile/phone/lte/ltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/tmobile/phone/lte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/tmobile/phone/phonelte.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/tmobile/phone/lte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/tmobile/phone/lte/ltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/tmobile/phone/lte/" +filename);
                File bfile =new File("errors/tmobile/phone/lte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

    } 
    
    //
    //
    //Next Function
    //
    //
    
    public static void nonltetimeouttmobile () throws Exception{
        //System.out.println("Looking for NON LTE Timeout files");
        //the following code runs a regex to look if a timeout occured
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/tmobile/phone/nonlte/nonltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/tmobile/phone/nonlte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/tmobile/phone/leftover.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/tmobile/phone/nonlte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Non-LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        //catch(Exception exc)
        //{
        //    System.out.println("unable to move one or more non lte files");
        //}
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the NONLTE timeout files into the timeout folder
        FileReader fr = new FileReader("errors/tmobile/phone/nonlte/nonltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/tmobile/phone/nonlte/" +filename);
                File bfile =new File("errors/tmobile/phone/nonlte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);
                    
                }
                //outStream.flush(); //just added this...
                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }





public static void ltetimeoutverizon () throws Exception{
        //System.out.println("Looking for LTE Timeout files");
        //the following code runs a regex to look if a LTE timeout occurred
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/verizon/phone/lte/ltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/verizon/phone/lte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/verizon/phone/phonelte.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/verizon/phone/lte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the LTE files into the input folder
        FileReader fr = new FileReader("errors/verizon/phone/lte/ltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/verizon/phone/lte/" +filename);
                File bfile =new File("errors/verizon/phone/lte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");

    } 
    
    //
    //
    //Next Function
    //
    //
    
    public static void nonltetimeoutverizon () throws Exception{
        //System.out.println("Looking for NON LTE Timeout files");
        //the following code runs a regex to look if a timeout occured
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/verizon/phone/nonlte/nonltetimeout.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/verizon/phone/nonlte/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/verizon/phone/leftover.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("errors/verizon/phone/nonlte/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*TIMEOUT.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Non-LTE Timeout Files");
            //System.out.println(debug2 + " Files Leftover");
            //debug += debug2;
            //System.out.println(debug + " Total Files");
        }
        //catch(Exception exc)
        //{
        //    System.out.println("unable to move one or more non lte files");
        //}
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the NONLTE timeout files into the timeout folder
        FileReader fr = new FileReader("errors/verizon/phone/nonlte/nonltetimeout.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("errors/verizon/phone/nonlte/" +filename);
                File bfile =new File("errors/verizon/phone/nonlte/timeout/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);
                    
                }
                //outStream.flush(); //just added this...
                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        //System.out.println(counter + " files moved successfully!");
    }
}
