package iperfprocess;

import java.io.*;
//this is used to pass text filenames
import java.util.Scanner;
//this is used for our regular expressions
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * This class further processes the bashed service providers.
 */
public class parse
{

    public static void process() throws Exception
    { 
        Scanner s = null;
        try {
            s = new Scanner(new BufferedReader(new FileReader("att.txt")));
            String filename = "nothing";
            while (s.hasNext()) {
                filename = s.next();

                FileWriter fw = new FileWriter("temp/att/upload" + filename);
                BufferedWriter bw = new BufferedWriter(fw);
                FileWriter dfw = new FileWriter("temp/att/download" + filename);
                BufferedWriter dbw = new BufferedWriter(dfw);

                FileReader fr = new FileReader("attbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                Boolean incomplete = true; //this is to check whether a N/A needs to be printed, never needs to be printed if no effective service
                String lineString = null;
                //gets the upload data
                lineString = br.readLine();
                if (lineString.equals("no effective service"))
                {
                    //we do nothing and skip the file, woohooo!
                }
                else
                {

                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 1 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    //this gets the third throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the third throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                                        
                    //this gets the fourth throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the fourth throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("====================== Average Broadband ======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    try{    

                    }
                    catch(Exception exc){
                        System.out.println ("could not pass file");
                    }
                    bw.close();
                    fw.close();
                    dbw.close();
                    dfw.close();
                }
            }
        } finally {
            if (s != null) {
                System.out.println ("Finished parsing AT&T data");
                s.close();
                condense.attdata();
            }
        }    
    }
    
    
    
    public static void sprintprocess() throws Exception
    { 
        Scanner s = null;
        try {
            s = new Scanner(new BufferedReader(new FileReader("sprint.txt")));
            String filename = "nothing";
            while (s.hasNext()) {
                filename = s.next();

                FileWriter fw = new FileWriter("temp/sprint/upload" + filename);
                BufferedWriter bw = new BufferedWriter(fw);
                FileWriter dfw = new FileWriter("temp/sprint/download" + filename);
                BufferedWriter dbw = new BufferedWriter(dfw);

                FileReader fr = new FileReader("sprintbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                Boolean incomplete = true; //this is to check whether a N/A needs to be printed, never needs to be printed if no effective service
                String lineString = null;
                //gets the upload data
                lineString = br.readLine();
                if (lineString.equals("no effective service"))
                {
                    //we do nothing and skip the file, woohooo!
                }
                else
                {

                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 1 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    //this gets the third throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the third throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                                        
                    //this gets the fourth throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the fourth throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("====================== Average Broadband ======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    try{    

                    }
                    catch(Exception exc){
                        System.out.println ("could not pass file");
                    }
                    bw.close();
                    fw.close();
                    dbw.close();
                    dfw.close();
                }
            }
        } finally {
            if (s != null) {
                System.out.println ("Finished parsing Sprint data");
                s.close();
                condense.sprintdata();
            }
        }    
    }
    
    
    
    public static void tmobileprocess() throws Exception
    { 
        Scanner s = null;
        try {
            s = new Scanner(new BufferedReader(new FileReader("tmobile.txt")));
            String filename = "nothing";
            while (s.hasNext()) {
                filename = s.next();

                FileWriter fw = new FileWriter("temp/tmobile/upload" + filename);
                BufferedWriter bw = new BufferedWriter(fw);
                FileWriter dfw = new FileWriter("temp/tmobile/download" + filename);
                BufferedWriter dbw = new BufferedWriter(dfw);

                FileReader fr = new FileReader("tmobilebashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                Boolean incomplete = true; //this is to check whether a N/A needs to be printed, never needs to be printed if no effective service
                String lineString = null;
                //gets the upload data
                lineString = br.readLine();
                if (lineString.equals("no effective service"))
                {
                    //we do nothing and skip the file, woohooo!
                }
                else
                {

                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 1 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    //this gets the third throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the third throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                                        
                    //this gets the fourth throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the fourth throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("====================== Average Broadband ======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    try{    

                    }
                    catch(Exception exc){
                        System.out.println ("could not pass file");
                    }
                    bw.close();
                    fw.close();
                    dbw.close();
                    dfw.close();
                }
            }
        } finally {
            if (s != null) {
                System.out.println ("Finished parsing T-Mobile data");
                s.close();
                condense.tmobiledata();
            }
        }    
    }
    
    
    
    public static void verizonprocess() throws Exception
    { 
        Scanner s = null;
        try {
            s = new Scanner(new BufferedReader(new FileReader("verizon.txt")));
            String filename = "nothing";
            while (s.hasNext()) {
                filename = s.next();

                FileWriter fw = new FileWriter("temp/verizon/upload" + filename);
                BufferedWriter bw = new BufferedWriter(fw);
                FileWriter dfw = new FileWriter("temp/verizon/download" + filename);
                BufferedWriter dbw = new BufferedWriter(dfw);

                FileReader fr = new FileReader("verizonbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                Boolean incomplete = true; //this is to check whether a N/A needs to be printed, never needs to be printed if no effective service
                String lineString = null;
                //gets the upload data
                lineString = br.readLine();
                if (lineString.equals("no effective service"))
                {
                    //we do nothing and skip the file, woohooo!
                }
                else
                {

                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 1 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 2 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the second throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    //this gets the third throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 3 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................
                    
                    //this gets the third throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                                        
                    //this gets the fourth throughput data for upload
                    while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 4 =======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            bw.write(matcher.group(1));
                            bw.newLine();
                            incomplete = false;
                        }

                        //System.out.println ("iteration: " + x);
                    }
                    if(incomplete.equals(true))
                    {
                        bw.write("N/A");
                    }
                    else
                    {
                        bw.write("flag");
                        incomplete = true;
                    }
                    bw.newLine();
                    
                    //....................................................................................

                    //this gets the fourth throughput data for download 
                    while((lineString= br.readLine())!= null && !lineString.equals("====================== Average Broadband ======================")){

                        Pattern pattern = 
                            Pattern.compile("[0-9]*:.(.*)");
                        Matcher matcher = pattern.matcher(lineString);
                        if(matcher .matches()){

                            dbw.write(matcher.group(1));
                            dbw.newLine();
                            incomplete = false;
                        }

                    }
                    if(incomplete.equals(true))
                    {
                      dbw.write("N/A");
                    }
                    else
                    {
                    dbw.write("flag");
                    incomplete = true;
                    }
                    dbw.newLine();

                    //................................................................................................
                    
                    try{    

                    }
                    catch(Exception exc){
                        System.out.println ("could not pass file");
                    }
                    bw.close();
                    fw.close();
                    dbw.close();
                    dfw.close();
                }
            }
        } finally {
            if (s != null) {
                System.out.println ("Finished parsing Verizon data");
                s.close();
                condense.verizondata();
            }
        }    
    }
}
