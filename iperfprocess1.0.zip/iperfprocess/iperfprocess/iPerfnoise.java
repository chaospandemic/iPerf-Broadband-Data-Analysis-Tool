package iperfprocess;
/**
 * This is the main function for the Iperf noise calculation and graph plotting
 * 
 * @author Donald Willis 
 * @version 1.0
 */
import java.io.*;

public class iPerfnoise
{
    public static class Global {

        public static String sp = null;
    }
    public static void att() throws Exception
    {
        System.out.println ("Starting the iPerf (on wireless) Noise Plotter");
        Global.sp="AT&T";
        String filename = null;
        Process p = Runtime.getRuntime().exec("c:/iperfprocess/getfinal.bat");
        p.waitFor();

        System.out.println ("Parsing AT&T files");
        parse.process();
        

        FileReader fr = new FileReader("attparsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);
        System.out.println ("Calculating noise for AT&T files");
        while((filename= br.readLine())!= null){
            System.out.println("AT&T " + filename + " graph");
            process.data(filename);
        }
        
        System.out.println("Creating location CSV files for AT&T");
        location.attparse();
        location.attcompile(Global.sp);
        
        sprint();
    }
    
    public static void sprint() throws Exception
    {
        
        Global.sp="Sprint";
        String filename = null;
        

        System.out.println ("Parsing Sprint files");
        parse.sprintprocess();
        

        FileReader fr = new FileReader("sprintparsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);
        System.out.println ("Calculating noise for Sprint files");
        while((filename= br.readLine())!= null){
            System.out.println("Sprint " + filename + " graph");
            process.data(filename);
        }
        System.out.println("Creating location CSV files for Sprint");
        location.sprintparse();
        location.sprintcompile(Global.sp);
        
        tmobile();
    }
    
    public static void tmobile() throws Exception
    {
        
        Global.sp="T-Mobile";
        String filename = null;
        

        System.out.println ("Parsing T-Mobile files");
        parse.tmobileprocess();
        

        FileReader fr = new FileReader("tmobileparsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);
        System.out.println ("Calculating noise for T-Mobile files");
        while((filename= br.readLine())!= null){
            System.out.println("T-Mobile " + filename + " graph");
            process.data(filename);
        }
        System.out.println("Creating location CSV files for T-Mobile");
        location.tmobileparse();
        location.tmobilecompile(Global.sp);
        
        verizon();
    }
    
    public static void verizon() throws Exception
    {
        
        Global.sp="Verizon";
        String filename = null;
        

        System.out.println ("Parsing Verizon files");
        parse.verizonprocess();
        

        FileReader fr = new FileReader("verizonparsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);
        System.out.println ("Calculating noise for Verizon files");
        while((filename= br.readLine())!= null){
            System.out.println("Verizon " + filename + " graph");
            process.data(filename);
        }
        System.out.println("Creating location CSV files for Verizon");
        location.verizonparse();
        location.verizoncompile(Global.sp);
    }
}

