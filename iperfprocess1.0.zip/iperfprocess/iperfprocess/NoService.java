package iperfprocess;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class SeparateData here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NoService
{
    public static void moveatt () throws Exception{
        System.out.println("Separating \"no service\" data");
        //the following code runs a regex to look if no effective service
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/att/noservice.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/att/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/att/leftovers.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("attbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();
                //this was all test code
                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                
                while((lineString= br.readLine())!= null){
                   // Pattern pattern = 
                     //   Pattern.compile(".*no effective service.*");
                    //Matcher matcher = pattern.matcher(lineString);
                    //if(matcher.matches()){
                        //System.out.println(lineString);
                        if (lineString.equals("no effective service"))
                        {
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag = false)
                {
                    lbw.write(filename);
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " No Effective Service files");
            //System.out.println(debug2 + " Files Leftover");
            //System.out.println((debug + debug2) + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the noservice files into the input folder
        FileReader fr = new FileReader("errors/att/noservice.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("attbashed/" + filename);
                File bfile =new File("errors/att/noservice/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        }
        
        
        //System.out.println(counter + " files moved successfully!");

    } 






public static void movesprint () throws Exception{
        System.out.println("Separating \"no service\" data");
        //the following code runs a regex to look if no effective service
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/sprint/noservice.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/sprint/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/sprint/leftovers.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("sprintbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();
                //this was all test code
                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                
                while((lineString= br.readLine())!= null){
                   // Pattern pattern = 
                     //   Pattern.compile(".*no effective service.*");
                    //Matcher matcher = pattern.matcher(lineString);
                    //if(matcher.matches()){
                        //System.out.println(lineString);
                        if (lineString.equals("no effective service"))
                        {
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag = false)
                {
                    lbw.write(filename);
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " No Effective Service files");
            //System.out.println(debug2 + " Files Leftover");
            //System.out.println((debug + debug2) + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the noservice files into the input folder
        FileReader fr = new FileReader("errors/sprint/noservice.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("sprintbashed/" + filename);
                File bfile =new File("errors/sprint/noservice/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        }
        
        
        //System.out.println(counter + " files moved successfully!");

    } 






public static void movetmobile () throws Exception{
        System.out.println("Separating \"no service\" data");
        //the following code runs a regex to look if no effective service
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/tmobile/noservice.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/tmobile/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/tmobile/leftovers.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("tmobilebashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();
                //this was all test code
                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                
                while((lineString= br.readLine())!= null){
                   // Pattern pattern = 
                     //   Pattern.compile(".*no effective service.*");
                    //Matcher matcher = pattern.matcher(lineString);
                    //if(matcher.matches()){
                        //System.out.println(lineString);
                        if (lineString.equals("no effective service"))
                        {
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag = false)
                {
                    lbw.write(filename);
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " No Effective Service files");
            //System.out.println(debug2 + " Files Leftover");
            //System.out.println((debug + debug2) + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the noservice files into the input folder
        FileReader fr = new FileReader("errors/tmobile/noservice.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("tmobilebashed/" + filename);
                File bfile =new File("errors/tmobile/noservice/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        }
        
        
        //System.out.println(counter + " files moved successfully!");

    } 






public static void moveverizon () throws Exception{
        System.out.println("Separating \"no service\" data");
        //the following code runs a regex to look if no effective service
        Scanner s = null;
        FileWriter fw = new FileWriter("errors/verizon/noservice.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("errors/verizon/leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("errors/verizon/leftovers.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("verizonbashed/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();
                //this was all test code
                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                
                while((lineString= br.readLine())!= null){
                   // Pattern pattern = 
                     //   Pattern.compile(".*no effective service.*");
                    //Matcher matcher = pattern.matcher(lineString);
                    //if(matcher.matches()){
                        //System.out.println(lineString);
                        if (lineString.equals("no effective service"))
                        {
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag = false)
                {
                    lbw.write(filename);
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " No Effective Service files");
            //System.out.println(debug2 + " Files Leftover");
            //System.out.println((debug + debug2) + " Total Files");
        }
        finally {
            if (s != null) {
                //System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the noservice files into the input folder
        FileReader fr = new FileReader("errors/verizon/noservice.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("verizonbashed/" + filename);
                File bfile =new File("errors/verizon/noservice/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        }
        
        
        //System.out.println(counter + " files moved successfully!");

    } 
}