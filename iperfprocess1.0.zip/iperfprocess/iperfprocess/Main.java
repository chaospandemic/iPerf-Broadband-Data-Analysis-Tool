package iperfprocess;

import java.io.*;
/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main
{
    public static void main() throws Exception
    {
        System.out.println("iPerf Data Processor 1.0");
        System.out.println ("Author: Donald Willis\n\n");
        String ans = null;

        //we open up a buffered reader to accept input by the user in the terminal window
        InputStreamReader ians = new InputStreamReader(System.in) ;
        BufferedReader bans = new BufferedReader(ians) ;
        try {
            System.out.println("Are the iPerf files located in c:/iperfprocess/iperfraw/  'y' or 'n'");
            ans = bans.readLine();
        }
        catch (IOException err) {
            System.out.println("Error reading line");
        }
        if(ans.equals("y"))
        {
            System.out.println("check successful");
        }
        else
        {
            System.out.println("iPerf files must located in c:/iperfprocess/iperfraw/");
            System.out.println("fix it and run the program again");
            return;
        }

        //creating a list of filenames
        Process p = Runtime.getRuntime().exec("c:/iperfprocess/getnames.bat");
        p.waitFor();

        //read the println
        System.out.println("Separating files by service provider...");
        verizon.move();
        sprint.move();
        tmobile.move();
        att.move();
        altsprint.move();

        //create script for bash processing
        bashprocess.process();

        System.out.println("");
        System.out.println("WARNING: READ THE FOLLOWING CAREFULLY");
        System.out.println("");
        System.out.println("It is possible that the service provider was not located in the iPerf file;");
        System.out.println("These files will be skipped. If you want to manually process them, ");
        System.out.println("go to c:/iperfprocess/iperfraw and retrieve them now, they will be deleted on program completion.");

        System.out.println("");
        System.out.println("When ready:");
        System.out.println("Open up a a CMD and type attrib –r +s C:\\iperfprocess");
        System.out.println("run C:\\iperfprocess\\process.bat");
        System.out.println("when the script completes, type a letter into this console and hit enter");
        try {
            ans = bans.readLine();
        }
        catch (IOException err) {
            System.out.println("Error reading line");
        }

        //start noise calculations
        iPerfnoise.att(); //the other providers are called by each other

        //Error Case Analysis
        temp.mkdirs();

        SeparatePhoneData.moveatt();
        LTE.phoneatt();
        Timeout.ltetimeoutatt();
        Connect.lteatt();
        Write.lteatt(); 
        Timeout.nonltetimeoutatt();
        Connect.nonlteatt();
        Write.nonlteatt();

        netbook.moveatt();
        nLTE.netbookatt();
        nTimeout.ltetimeoutatt();
        nConnect.lteatt();
        nWrite.lteatt(); 
        nTimeout.nonltetimeoutatt();
        nConnect.nonlteatt();
        nWrite.nonlteatt();

        NoService.moveatt();

        SeparatePhoneData.movesprint();
        LTE.phonesprint();
        Timeout.ltetimeoutsprint();
        Connect.ltesprint();
        Write.ltesprint(); 
        Timeout.nonltetimeoutsprint();
        Connect.nonltesprint();
        Write.nonltesprint();

        netbook.movesprint();
        nLTE.netbooksprint();
        nTimeout.ltetimeoutsprint();
        nConnect.ltesprint();
        nWrite.ltesprint(); 
        nTimeout.nonltetimeoutsprint();
        nConnect.nonltesprint();
        nWrite.nonltesprint();

        NoService.movesprint();

        SeparatePhoneData.movetmobile();
        LTE.phonetmobile();
        Timeout.ltetimeouttmobile();
        Connect.ltetmobile();
        Write.ltetmobile(); 
        Timeout.nonltetimeouttmobile();
        Connect.nonltetmobile();
        Write.nonltetmobile();

        netbook.movetmobile();
        nLTE.netbooktmobile();
        nTimeout.ltetimeouttmobile();
        nConnect.ltetmobile();
        nWrite.ltetmobile(); 
        nTimeout.nonltetimeouttmobile();
        nConnect.nonltetmobile();
        nWrite.nonltetmobile();

        NoService.movetmobile();

        SeparatePhoneData.moveverizon();
        LTE.phoneverizon();
        Timeout.ltetimeoutverizon();
        Connect.lteverizon();
        Write.lteverizon(); 
        Timeout.nonltetimeoutverizon();
        Connect.nonlteverizon();
        Write.nonlteverizon();

        netbook.moveverizon();
        nLTE.netbookverizon();
        nTimeout.ltetimeoutverizon();
        nConnect.lteverizon();
        nWrite.lteverizon(); 
        nTimeout.nonltetimeoutverizon();
        nConnect.nonlteverizon();
        nWrite.nonlteverizon();

        NoService.moveverizon();

        System.out.println("Performing some cleanup...");
        temp.deldirs();
		System.out.println("Location data .CSV files are located in c:/iperfprocess/output/");
        System.out.println("Program finished.");
    }
}
