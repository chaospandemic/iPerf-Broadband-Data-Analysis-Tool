package iperfprocess;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class SeparateData here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class verizon
{
    public static void move () throws Exception{
        System.out.println("Looking for Verizon data");
        //the following code runs a regex to look if verizon was used
        Scanner s = null;
        FileWriter fw = new FileWriter("verizonfiles.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter lfw = new FileWriter("leftover.txt");
        BufferedWriter lbw = new BufferedWriter(lfw);

        try {
            s = new Scanner(new BufferedReader(new FileReader("processor.txt")));
            String filename = "nothing";
            String lineString = null;
            int debug = 0, debug2 = 0;
            Boolean flag = false;
            while (s.hasNext()) {
                filename = s.next();
                FileReader fr = new FileReader("iperfraw/" + filename);
                BufferedReader br = new BufferedReader(fr);
                flag = false;
                //lineString = br.readLine();

                //Pattern pattern = Pattern.compile(".*Phone.*");
                //Matcher matcher = pattern.matcher(lineString);
                //if(matcher.matches()){
                //    
                //    bw.write(filename);
                //    bw.newLine();
                //    debug++;
                //}
                //else
                //{
                while((lineString= br.readLine())!= null){
                    Pattern pattern = 
                        Pattern.compile(".*Verizon.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher.matches()){
                        debug ++;
                        //System.out.println(filename);
                        bw.write(filename);
                        bw.newLine();
                        //bw.flush();
                        flag = true;
                    }

                }

                if(flag.equals(false))
                {
                    lbw.write(filename);
                    lbw.newLine();
                    //lbw.flush();
                    debug2++;
                }
                //}
            }
            System.out.println(debug + " Files Matched!");
            System.out.println(debug2 + " Files Leftover");
            debug += debug2;
            System.out.println(debug + " Total Files");
        }
        finally {
            if (s != null) {
                System.out.println ("Time to move theses files...");
                s.close();
                bw.close();
                lbw.close();
            }
        } 

        //the rest of this code copies the phone files into the input folder
        FileReader fr = new FileReader("verizonfiles.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 0;
        while((filename= br.readLine())!= null){

            InputStream inStream = null;
            OutputStream outStream = null;

            try{

                File afile =new File("iperfraw/" + filename);
                File bfile =new File("verizon/" + filename);

                inStream = new FileInputStream(afile);
                outStream = new FileOutputStream(bfile);

                byte[] buffer = new byte[1024];

                int length;
                //copy the file content in bytes 
                while ((length = inStream.read(buffer)) > 0){

                    outStream.write(buffer, 0, length);

                }

                inStream.close();
                outStream.close();
                System.gc();
                //delete the original file
                afile.delete();

            }catch(IOException e){
                e.printStackTrace();
            }
            counter ++;
        } 
        
        System.out.println(counter + " files moved successfully!");

    } 
}
