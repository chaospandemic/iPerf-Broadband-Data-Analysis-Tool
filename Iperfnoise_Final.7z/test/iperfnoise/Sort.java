package iperfnoise;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class Sort here.
 * 
 * @author Donald Willis
 * @version 0.0.4 alpha
 */
public class Sort
{

    /**
     * Constructor for objects of class Sort
     */
    public void it() throws Exception
    {
        /*
        ArrayList<String> rows = new ArrayList<String>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));

        String s;
        while((s = reader.readLine())!=null)
        rows.add(s);

        Collections.sort(rows, new AlphanumComparator());

        FileWriter writer = new FileWriter("filename.txt");
        for(String cur: rows)
        writer.write(cur+"\n");

        reader.close();
        writer.close();
         */
        Scanner sc = null;

        try {
            sc = new Scanner(new BufferedReader(new FileReader("sortthese.txt")));
            String filename = "nothing";
            while (sc.hasNext()) {
                filename = sc.next();

                FileReader fr = new FileReader("temp\\"+filename);
                BufferedReader br = new BufferedReader(fr);

                ArrayList<String> rows = new ArrayList<String>();
                BufferedReader reader = new BufferedReader(new FileReader("temp//"+filename));

                String s;
                while((s = reader.readLine())!=null)
                    rows.add(s);

                Collections.sort(rows, new AlphanumComparator());

                FileWriter writer = new FileWriter("temp2//"+filename);
                for(String cur: rows)
                    writer.write(cur+"\n");

                reader.close();
                writer.close();

            }

            try{    

            }
            catch(Exception exc){
                System.out.println ("could not pass file");
            }
        }
        finally {
            if (sc != null) {
                System.out.println ("Finished processing data");
                sc.close();
            }

        }
    }
}
