#!/bin/bash

####################################################################
# Identify upload/download speed second-by-second.
####################################################################


for File in $*
do
{
    # Decide if the input file is for a phone or a netbook
    phone=0
    grep -q '^Device ID:' $File
    if [ $? -eq 0 ] ##### PHONE #####
    then
        phone=1
    fi

 
    # Location ID
    if [ $phone -eq 1 ]
    then
        locID=`grep '^Location ID:' $File | awk '{print $3}'`
    else
        locID=`grep '^Location:' $File | awk '{print $2}'`
    fi


    # Date, time, provider, operator, etc.
    if [ $phone -eq 1 ] ##### PHONE #####
    then
        month=`grep 'Testing started' -m 1 $File | awk '{print $5}'` 

        case "$month" in
            Jan) month="01" ;;
            Feb) month="02" ;;
            Mar) month="03" ;;
            Apr) month="04" ;;
            May) month="05" ;;
            Jun) month="06" ;;
            Jul) month="07" ;;
            Aug) month="08" ;;
            Sep) month="09" ;;
            Oct) month="10" ;;
            Nov) month="11" ;;
            Dec) month="12" ;;
            *) month="ERROR: Invalid month" ;;
        esac

        day=`grep 'Testing started' -m 1 $File | awk '{print $6}'` 
        year=`grep 'Testing started' -m 1 $File | awk '{print $9}'` 
        date=`echo $month/$day/$year`
        time=`grep 'Testing started' -m 1 $File | awk '{print $7}'`
        deviceID=`grep '^Device ID:' -m 1 $File | awk '{print $3}'`
        provider=""
        operator=""
        provider=`grep '^NetworkProvider:' -m 1 $File | awk '{print $2}'` 
        operator=`grep '^NetworkOperator:' -m 1 $File | awk '{print $2}'` 
        netType=`grep 'ConnectionType:' -m 1 $File | awk '{print $2}'` 
        clientType='Phone' 
    else ##### NETBOOK #####
        date=`grep '../../.... ..:..:..' -m 1 $File | awk '{print $1}'`
        time=`grep '../../.... ..:..:..' -m 1 $File | awk '{print $2}'`
        deviceID=`grep '^Host name:' $File | awk '{print $3}'`
        provider=`grep '^Network Provider:' $File | awk '{print $3}'`
        operator=""
        netType="NA"
        clientType='Netbook'
    fi


    ##########################################################################
    # Print Data
    ##########################################################################

    # Check if the testing was quit by a user
    grep -q '^Quitting operations' $File
    if [ $? -eq 0 ] # Test was quitted by a user
    then
        echo "ERROR: QUIT BY USER"
        continue;
    fi

    # Check if the testing failed the three trials of connectivity tests.
    file_size=$( stat -c %s $File)
    if [ $file_size -lt 5000 ]  # We assume that the file size is less than 5000 bytes, connectivity test failed
    then
        echo "no effective service"
        continue;
    fi


    echo "$locID, $date, $time, $provider, $operator, $netType, $lat, $long, $deviceID, $clientType, "


    ##############################################################################
    # TCP Upload and Download Speed
    ##############################################################################
    ### This script adds all the Upload tests and Download tests
    # for the TCP for each thread.
    # There are 8 threads numbered: 3,4,5,6,7,8,10,11.
    # There are 4 TCP tests each having an upload and download portion.
    # For each thread, the script is identical other than the thread numbers.
    #
    ### Each line in this script begining with the 'sed'
    # command executes like this, sed looks for "Starting Test 1: Iperf"
    # String and "Starting Test 2: Iperf" and pipes the content
    # between the two strings.
    ##############################################################################

    cp $File temp.txt
    rm -f my_tcp[1-4].txt

    if [ $phone -eq 1 ] ##### Phone #####
    then
        sed  -e '0,/Starting Test 1:/d' -e '/Starting Test 2:/,$d' temp.txt > my_tcp1.txt
        sed  -e '0,/Starting Test 2:/d' -e '/Starting Test 3:/,$d' temp.txt > my_tcp2.txt
        sed  -e '0,/Starting Test 4:/d' -e '/Starting Test 5:/,$d' temp.txt > my_tcp3.txt
        sed  -e '0,/Starting Test 5:/d' -e '/Starting Test 6:/,$d' temp.txt > my_tcp4.txt
    else
        sed  -e '0,/Starting Test 1\.\.\./d' -e '/Starting Test 2.../,$d' temp.txt > my_tcp1.txt
        sed  -e '0,/Starting Test 2.../d' -e '/Starting Test 3.../,$d' temp.txt > my_tcp2.txt
        sed  -e '0,/Starting Test 4.../d' -e '/Starting Test 5.../,$d' temp.txt > my_tcp3.txt
        sed  -e '0,/Starting Test 5.../d' -e '/Starting Test 6.../,$d' temp.txt > my_tcp4.txt
    fi

    counter2=1;
    error_flag=0
    while [ $counter2 -lt 5 ]
    do

        ### Check timeout case 
        grep -q '^Iperf timed out after 120 seconds' my_tcp${counter2}.txt
        if [ $? -eq 0 ] ##### Timed Out in Phone #####
        then
            echo "ERROR: TIMEOUT"
            error_flag=1
            break;
        fi

        grep -q '^Test Timed Out' my_tcp${counter2}.txt
        if [ $? -eq 0 ] ##### Timed Out in Network #####
        then
            echo "ERROR: TIMEOUT"
            error_flag=1
            break;
        fi


        ### Check "connect failed" case 
        grep -q '^connect failed:' my_tcp${counter2}.txt
        if [ $? -eq 0 ] ##### Connect Error #####
        then
            echo "ERROR: CONNECT ERROR"
            error_flag=1
            break;
        fi


        ### Check "write1 failed" and "write2 failed" cases
        grep -q '^write1 failed:' my_tcp${counter2}.txt
        if [ $? -eq 0 ] 
        then
            echo "ERROR: WRITE ERROR"
            error_flag=1
            break;
        fi

        grep -q '^write2 failed:' my_tcp${counter2}.txt
        if [ $? -eq 0 ] 
        then
            echo "ERROR: WRITE ERROR"
            error_flag=1
            break;
        fi

        up[${counter2}]=""
        down[${counter2}]=""

        #
        # Create up and down files for the threads 3, 4, 5, and 6
        #
        rm -f thread[3-6].txt
        rm -f up[3-6].txt
        rm -f up_num[3-6].txt
        rm -f down[3-6].txt
        rm -f down_num[3-6].txt
        counter3=3;
        up_sec=120
        down_sec=120    
        while [ $counter3 -lt 7 ]
        do
            grep ${counter3}\] my_tcp${counter2}.txt > thread${counter3}.txt

            sed -n '/local/,/local/p' thread${counter3}.txt \
                   | sed '/local/d'                         \
                   | sed '$d' > up${counter3}.txt

            awk -F'-' '{print $2}' up${counter3}.txt | awk '{print $5}' > up_num${counter3}.txt
            temp_sec=`wc -l up_num${counter3}.txt | cut -d' ' -f 1`
            if [ $temp_sec -lt $up_sec ]
            then
                up_sec=$temp_sec
            fi


            sed '/local/,/local/d' thread${counter3}.txt \
                 | sed '$d' > down${counter3}.txt

            awk -F'-' '{print $2}' down${counter3}.txt | awk '{print $5}' > down_num${counter3}.txt
            temp_sec=`wc -l down_num${counter3}.txt | cut -d' ' -f 1`
            if [ $temp_sec -lt $down_sec ]
            then
                down_sec=$temp_sec
            fi

            counter3=$((counter3+1))
        done


        #
        # Determine the up and down bandwidths second-by-second.
        #
        echo "================= Upload Speed for Test ${counter2} ======================="
        counter3=1;
        while [ $counter3 -le $up_sec ]
        do
            rm -f number.txt
            awk NR==${counter3} up_num3.txt > number.txt
            awk NR==${counter3} up_num4.txt >> number.txt
            awk NR==${counter3} up_num5.txt >> number.txt
            awk NR==${counter3} up_num6.txt >> number.txt
            total=`awk '{sum+=$1} END{printf("%.2f\n",sum)}' number.txt`
            echo "${counter3}: $total"
            
            counter3=$((counter3+1))
        done

        echo "================= Download Speed for Test ${counter2} ======================="
        counter3=1;
        while [ $counter3 -le $down_sec ]
        do
            rm -f number.txt
            awk NR==${counter3} down_num3.txt > number.txt
            awk NR==${counter3} down_num4.txt >> number.txt
            awk NR==${counter3} down_num5.txt >> number.txt
            awk NR==${counter3} down_num6.txt >> number.txt
            total=`awk '{sum+=$1} END{printf("%.2f\n",sum)}' number.txt`
            echo "${counter3}: $total"

            counter3=$((counter3+1))
        done

        counter2=$((counter2+1))
    done

    rm -f tcp[1-4].txt

    if [ $error_flag -eq 1 ]  
    then
        continue;
    fi

    counter=3; #to track thread number in the test result
    for variable in " 3" " 4" " 5" " 6"
    do
        cat my_tcp1.txt | grep "\[ ${variable}\]  0.0-" | grep -v "\[ ${variable}\]  0.0- 1.0" | awk -F'-' '{print $2 }' |  awk '{ if (NR==1) print "Up'${counter}' " $5} { if (NR==2) print "Down'${counter}' " $5}' >> tcp1.txt
        cat my_tcp2.txt | grep "\[ ${variable}\]  0.0-" | grep -v "\[ ${variable}\]  0.0- 1.0" | awk -F'-' '{print $2 }' |  awk '{ if (NR==1) print "Up'${counter}' " $5} { if (NR==2) print "Down'${counter}' " $5}' >> tcp2.txt
        cat my_tcp3.txt | grep "\[ ${variable}\]  0.0-" | grep -v "\[ ${variable}\]  0.0- 1.0" | awk -F'-' '{print $2 }' |  awk '{ if (NR==1) print "Up'${counter}' " $5} { if (NR==2) print "Down'${counter}' " $5}' >> tcp3.txt
        cat my_tcp4.txt | grep "\[ ${variable}\]  0.0-" | grep -v "\[ ${variable}\]  0.0- 1.0" | awk -F'-' '{print $2 }' |  awk '{ if (NR==1) print "Up'${counter}' " $5} { if (NR==2) print "Down'${counter}' " $5}' >> tcp4.txt

        counter=$((counter+1))
    done


    echo "====================== Average Broadband ======================"
    counter2=1;
    while [ $counter2 -lt 5 ]
    do
        #If we have a too big TCP value, we convert it to 0. --> The big TCP value is an iPerf bug.
        up[$counter2]=`grep "^Up" tcp${counter2}.txt | awk 'BEGIN{total=0}{if($2 > 9999999999.99) total += 0; else total += $2;}END{printf "%.1f",total}'`
        down[$counter2]=`grep "^Down" tcp${counter2}.txt | awk 'BEGIN{total=0}{if($2 > 9999999999.99) total += 0; else total += $2;}END{printf "%.1f",total}'`

        ## Error Checking - If a value is unreasonable big, we should inteprete 
        ##                  it as zero, which is an iPerf error
        flag1=$( echo "${up[$counter2]} > 9999999999.99" | bc -l )
        flag2=$( echo "${down[$counter2]} > 9999999999.99" | bc -l )
        if [ $flag1 -eq 1 ]
        then
            up[$counter2]="ERROR"
        fi
        if [ $flag2 -eq 1 ]
        then
            down[$counter2]="ERROR"
        fi


        #
        ### TCP Result Printing
        #
        echo "Test ${counter2}: ${up[$counter2]}, ${down[$counter2]} "  

        counter2=$((counter2+1))
    done

    echo ""

    rm -f temp.txt

} < $File
done

rm -f my_tcp[1-4].txt
rm -f tcp[1-4].txt
rm -f down[3-6].txt
rm -f down_num[3-6].txt
rm -f thread[3-6].txt
rm -f up[3-6].txt
rm -f up_num[3-6].txt
rm -f number.txt
