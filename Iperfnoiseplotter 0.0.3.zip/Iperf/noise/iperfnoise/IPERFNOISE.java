package iperfnoise;
/**
 * This is the main function for the Iperf noise calculation and graph plotting
 * 
 * @author Donald Willis 
 * @version 0.0.3
 */
import java.io.*;
public class IPERFNOISE
{
    public static void main(String[] args) throws Exception
    {
        System.out.println ("Starting the Iperf on Wireless Noise Plotter 0.0.3");
        System.out.println ("Author: Donald Willis\n\n");
        
        
        
        String filename = null;
        int counter = 1;
        
            System.out.println ("Parsing files");
            Parse.process();
            System.out.println ("Done.");
            
        
        FileReader fr = new FileReader("parsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);
        
        while((filename= br.readLine())!= null){
            System.out.println ("Calculating noise for file " + counter);
            counter++;
            process.data(filename);
            System.out.println ("Done.");
        }
    
}
}
