To use the charts4j API, put this jar (found in the
charts4j-[VERSION]/lib directory) in your classpath:

charts4j-[VERSION].jar

To run the unit tests you will also need junit-[VERSION].jar

For Maven, include this XML snippet in your pom.xml.

<dependency>                                                                                                                                                                                                                                
  <groupId>com.googlecode.charts4j</groupId>                                                                                                                                                                                                
  <artifactId>charts4j</artifactId>                                                                                                                                                                                                         
  <version>[VERSION]</version>                                                                                                                                                                                                           
</dependency>                                                                                                                                                                                                                               

For Leiningen Clojure, users please use:

[com.googlecode.charts4j/charts4j "[VERSION]"] 