package iperfnoise;

import java.io.*;
//this is used to pass text filenames
import java.util.Scanner;
//this is used for our regular expressions
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Write a description of class Parse here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Parse
{

    public static void process() throws Exception
    { 
        Scanner s = null;
        try {
            s = new Scanner(new BufferedReader(new FileReader("processor.txt")));
            String filename = "nothing";
            while (s.hasNext()) {
                filename = s.next();
                
                FileWriter fw = new FileWriter("temp/upload" + filename);
                BufferedWriter bw = new BufferedWriter(fw);
                FileWriter dfw = new FileWriter("temp/download" + filename);
                BufferedWriter dbw = new BufferedWriter(dfw);

                FileReader fr = new FileReader(filename);
                BufferedReader br = new BufferedReader(fr);

                String lineString = null;
                //gets the upload data
                while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 1 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                //System.out.println ("iteration: " + x);
            }
            
            //this gets the second throughput data for download 
            while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 2 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
            }
                while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 2 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                //System.out.println ("iteration: " + x);
            }
            
            //this gets the second throughput data for download 
            while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 3 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
            }
            
            //this gets the third throughput data for upload
                while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 3 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                //System.out.println ("iteration: " + x);
            }
            
            //this gets the third throughput data for download 
            while((lineString= br.readLine())!= null && !lineString.equals("================= Upload Speed for Test 4 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
            }
            
             //this gets the fourth throughput data for upload
                while((lineString= br.readLine())!= null && !lineString.equals("================= Download Speed for Test 4 =======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    bw.write(matcher.group(1));
                    bw.newLine();
                }
                //System.out.println ("iteration: " + x);
            }
            
            //this gets the third throughput data for download 
            while((lineString= br.readLine())!= null && !lineString.equals("====================== Average Broadband ======================")){

                Pattern pattern = 
                    Pattern.compile("[1-9]:.(.*)");
                Matcher matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                     
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
                pattern = pattern.compile("10:.(.*)");
                matcher = pattern.matcher(lineString);
                if(matcher .matches()){
                    dbw.write(matcher.group(1));
                    dbw.newLine();
                }
            }
            
            try{    

            }
            catch(Exception exc){
                System.out.println ("could not pass file");
            }
            bw.close();
            fw.close();
            dbw.close();
            dfw.close();
        }
    } finally {
        if (s != null) {
            System.out.println ("Finished parsing data. Starting condenser...");
            s.close();
            condense.data();
        }
    }    
}
}
