package iperfnoise;

import com.googlecode.charts4j.CDF;
import java.io.*;

/**
 * This part of the program reads in noise rates and catagorizes them in blocks. They are blocked by noise rate and the total number of values in a block of noise rates is passed into an array
 * Once all noise rates have been catagorized, the array is passed into charts4j which utilizes the Google API to create our CDF plot.
 * @author Donald Willis & Ryan Loera 
 * @version 0.0.2
 */
public class preparecdf
{
    public static void graph (String filename)throws Exception{
        System.out.println(filename + " graph");
        Sort sort = new Sort();
        sort.it(filename);

        //once its sorted, we can read the file into an array, keep track of the #of values in the array
        //we will need a way to set the range being plotted.
        //find your grouping points and how many values are there
        //we will need to multiply the # of values of the groups by mutliplied .15 to allow it to plot correctly on the graph .15 may need to be adjusted at some point depending on the results
        //an array will be passed with the noise rates, and array with the range to be plotted

        FileReader fr = new FileReader("output/sortednoise" + filename);
        BufferedReader br = new BufferedReader(fr);
        double array[] = new double [11];
        int counter = 0;
        double compare;
        for(int x=0; x<11; x++)
        {
            array[x] = 0;
        }
        while((filename= br.readLine())!= null){ //this loop reads in

            compare = Double.parseDouble(filename);
            if (compare < 1)
            {
                array[0]++;
            }
            else if (compare <= 10)
            {
                array[1]++;
            }
            else if (compare <= 20)
            {
                array[2]++;
            }
            else if (compare <= 30)
            {
                array[3]++;
            }
            else if (compare <= 40)
            {
                array[4]++;
            }
            else if (compare <= 50)
            {
                array[5]++;
            }
            else if (compare <= 60)
            {
                array[6]++;
            }
            else if (compare <= 70)
            {
                array[7]++;
            }
            else if (compare <= 80)
            {
                array[8]++;
            }
            else if (compare <= 90)
            {
                array[9]++;
            }
            else
            {
                array[10]++;
            }            
        }
        
        for(int x=0; x<11; x++)
        {
            System.out.println(array[x]);
        }
        
        CDF cdf = new CDF();
        cdf.plotter(array);
    }
}
