
/**
 * Write a description of class averageThroughput here.
 * 
 * @author Donald Willis & Mike Fowler
 * @version 0.0.2
 */

import java.io.*;

public class averageThroughput
{
  public static void main(String[] args) throws Exception
    {
        System.out.println ("Program is running.");        
        
        FileReader fr = new FileReader("filenames.txt"); //this opens up a file named filename.txt
        BufferedReader br = new BufferedReader(fr);
        String filename = null;
        Boolean exist = false; //Used to show if the while loop has run more than once. Acts as a flag when opening the files
        
        while((filename= br.readLine())!= null)
        {
           averager.averager(filename, exist);
           exist = true;
        }
        
        compareAverage.compare();
        compareResults.results();
        
        System.out.println ("Program is Complete.");
    }
}
