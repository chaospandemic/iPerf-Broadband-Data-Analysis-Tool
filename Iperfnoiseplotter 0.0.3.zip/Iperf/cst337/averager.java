
/**
 * Write a description of class averager here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.io.*;

public class averager
{
   public static void averager( String filename, Boolean exist ) throws Exception{
       Boolean count = true;
       double total = 0;
       double num;
       String input = null;
       
       FileReader fr = new FileReader(filename);
       BufferedReader br = new BufferedReader(fr);
       //exist is passed to open for append mode if we have already written some values in the files from a previous loop
       FileWriter eastfw = new FileWriter("Eastserverfilename.txt", exist);
       FileWriter westfw = new FileWriter("Westserverfilename.txt", exist);
       BufferedWriter eastbw = new BufferedWriter(eastfw);
       BufferedWriter westbw = new BufferedWriter(westfw);
       
       while ( (input = br.readLine()) != null )
       {
           num = Double.parseDouble( input );
           total += num;
           //The first line is read in by the condition so we only read 9 more in the for loop
            for ( int i = 0; i < 9; i++ )
            {
                input = br.readLine();
                num = Double.parseDouble( input );
                total += num;
            }
            total /= 10;
       
            //count acts as a switching variable flag to determine which file we need to write to
            if ( count )
            {
                eastbw.write( Double.toString(total) );
                eastbw.newLine();
                count = false;
            }
            else
            {
                westbw.write( Double.toString(total) );
                westbw.newLine();
                count = true;
            }
            total = 0;
        }
        
        eastbw.close();
        westbw.close();
        br.close();
      
    }
}
