
/**
 * Write a description of class comapreResults here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.io.*;

public class compareResults
{
    public static void results() throws Exception
    {
        FileReader eastfr = new FileReader( "EastBetterThanWestBy.txt" );
        BufferedReader eastbr = new BufferedReader( eastfr );
        
        FileReader westfr = new FileReader( "WestBetterThanEastBy.txt" );
        BufferedReader westbr = new BufferedReader( westfr );
        
        int eastCount = 0;
        int westCount = 0;
        double eastValue;
        double westValue;
        double eastTotal = 0;
        double westTotal = 0;
        String eastInput;
        String westInput;
        
        while( ( eastInput = eastbr.readLine() ) != null )
        {
            eastCount++;
            eastValue = Double.parseDouble( eastInput );
            eastTotal += eastValue;
        }
        
        while( ( westInput = westbr.readLine() ) != null )
        {
            westCount++;
            westValue = Double.parseDouble( westInput );
            westTotal += westValue;
        }
        
        //If one server has more entries than the other by more than 250 then do something
        if ( (eastCount - westCount) > 250 )
        {
            System.out.println( "East server has " + (eastCount - westCount) + " more entries");
        }
        else if ( (westCount - eastCount) > 250 )
        {
            System.out.println( "West server has " + (westCount - eastCount) + " more entries");
        }
        
        //If one server's average is 20% greater than the other then do something
        if ( (eastTotal / eastCount) >= ( (westTotal / westCount) * 1.2 ) )
        {
            System.out.println( "East has a better average by " + (eastTotal / eastCount) + "%" );
        }
        else if ( (westTotal / westCount) >= ( (eastTotal / eastCount) * 1.2 ) )
        {
            System.out.println( "West has a better average by " + (westTotal / westCount) + "%" );
        }
        
        eastbr.close();
        westbr.close();
    }
}
