package iperfnoise;

import com.googlecode.charts4j.bchart;
import java.io.*;

/**
 * This part of the program reads in noise rates and catagorizes them in blocks. They are blocked by noise rate and the total number of values in a block of noise rates is passed into an array
 * Once all noise rates have been catagorized, the array is passed into charts4j which utilizes the Google API to create our CDF plot.
 * @author Donald Willis & Ryan Loera 
 * @version 0.0.4
 */
public class preparecdf
{
    public static void graph (String filename)throws Exception{
        String labels[] = new String [2];
        System.out.println(filename + " graph");

        if(filename.equals("downloaddata.txt"))
        {
            labels[1] = "Download";
        }
        else
        {
            labels[1] = "Upload";
        }

        Sort sort = new Sort();
        sort.it(filename);

        //once its sorted, we can read the file into an array, keep track of the #of values in the array
        //we will need a way to set the range being plotted.
        //find your grouping points and how many values are there
        //we will need to multiply the # of values of the groups by mutliplied .15 to allow it to plot correctly on the graph .15 may need to be adjusted at some point depending on the results
        //an array will be passed with the noise rates, and array with the range to be plotted

        FileReader fr = new FileReader("output/sortednoise" + filename);
        BufferedReader br = new BufferedReader(fr);
        FileReader cr = new FileReader("condensed/sp.txt");
        BufferedReader dr = new BufferedReader(cr);

        int array[] = new int [11];
        int counter = 0;
        double compare;

        labels[0] = dr.readLine();
        dr.close();
        cr.close();
        String f;

        for(int x=0; x<11; x++)
        {
            array[x] = 0;
        }
        while((f= br.readLine())!= null){ //this loop reads in
            if (f.equals("N/A"))
            {
                while ((f= br.readLine())!= null && f.equals("N/A"))
                {
                    //do nothing, honey badger dont care
                }
            }
            if(f != null)
            {
                compare = Double.parseDouble(f);
                //System.out.println(compare);
                if (compare < 5)
                {
                    array[0]++;
                }
                else if (compare <= 15)
                {
                    array[1]++;
                }
                else if (compare <= 25)
                {
                    array[2]++;
                }
                else if (compare <= 35)
                {
                    array[3]++;
                }
                else if (compare <= 45)
                {
                    array[4]++;
                }
                else if (compare <= 60)
                {
                    array[5]++;
                }
                else if (compare <= 70)
                {
                    array[6]++;
                }
                else if (compare <= 80)
                {
                    array[7]++;
                }
                else if (compare <= 90)
                {
                    array[8]++;
                }
                else if (compare <= 100)
                {
                    array[9]++;
                }
                else
                {
                    array[10]++;
                } 
            }
        }

        for(int x=0; x<11; x++)
        {
            System.out.println(array[x]);
            if (array[x] > 1000)
            {
                array[x] = 100;
            }
            else
                array[x]*=.1;
        }

        bchart cdf = new bchart();
        cdf.graph(array,labels);
    }
}
