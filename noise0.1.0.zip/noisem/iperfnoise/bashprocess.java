package iperfnoise;
import java.io.*;
/**
 * Write a description of class testor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bashprocess
{
    public static void main (String args[]) throws Exception{

        FileReader fr = new FileReader("processor.txt");
        BufferedReader br = new BufferedReader(fr);

        String filename = null;
        int counter = 1;
        while((filename= br.readLine())!= null){

            String cmd = "cd /cygdrive/c/users/asus/documents/iperf/noise/input";
            String cmd2 = "bash each_sec_extract.bash " + filename + " > " + filename;
            try {
                System.out.println ("starting to process file " + counter);
                FileWriter fbat = new FileWriter("input/process.bat");
                BufferedWriter bbat = new BufferedWriter(fbat);
                bbat.write("@ echo off");
                bbat.newLine();
                bbat.write("C:/cygwin/bin/bash -li /cygdrive/c/users/asus/documents/iperf/noise/input/each_sec_extract.bash /cygdrive/c/users/asus/documents/iperf/noise/input/" + filename + " > " + filename);
                bbat.newLine();
                bbat.close();
                fbat.close();
                Process p = Runtime.getRuntime().exec("c:/users/asus/documents/iperf/noise/input/process.bat");
                p.waitFor();
                System.out.println ("Done");

            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
            counter++;

        } 

    }
}

