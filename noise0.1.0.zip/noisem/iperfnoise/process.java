package iperfnoise;
/**
 * This method is the core of the program, it pulls out the ten second data and calculates the noise on the fly 
 * and prints it to a new file
 * 
 * @author Donald Willis
 * @version 0.0.4
 */
import java.io.*;
import java.util.Arrays;

public class process
{
    public static void data(String filename) throws Exception
    {
        FileReader fr = new FileReader("condensed\\" + filename);
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\noise" + filename);
        BufferedWriter bw = new BufferedWriter(fw);

        String lineString = null;
        Integer counter = 0;
        double result = 0;
        double array[] = new double [1024];
        Boolean clear = true;
        while((lineString= br.readLine())!= null){
            if (lineString.equals("N/A"))
            {
                bw.write(lineString);
                bw.newLine();
                while((lineString= br.readLine())!= null && lineString.equals("N/A"))
                {
                    bw.write(lineString);
                    bw.newLine();
                }
            }
            //System.out.println(lineString);
            if(lineString!=null)
            {
            if(lineString.equals("flag") && counter != 0)
            {

                //This sorting algorithym is not reliable --> Arrays.sort(array);

                int idx2, idx1;
                double temp;
                //----------------------------------------------
                // The 1st index is set to 0. On each loop it's 
                // compared against the length, and incremented.
                //----------------------------------------------
                for (idx1 = 0; idx1 < counter; idx1++)
                {
                    //--------------------------------------------
                    // The 2nd index is set to 1 position higher 
                    // than the 1st. On each loop it's compared 
                    // against the length, and incremented.
                    //--------------------------------------------
                    for (idx2 = idx1 +1; idx2 < counter; idx2++)
                    {
                        //------------------------------------------
                        // If the 1st number is greater than the 2nd
                        // number, the two numbers switch. The 2nd
                        // has to be stored so it's not overwritten.
                        //------------------------------------------
                        if (array[idx1] > array[idx2])
                        {
                            temp         = array[idx2];
                            array[idx2] = array[idx1];
                            array[idx1] = temp;
                        }
                    }
                }

                //using this one instead^^^^^
                counter --;

                result = (((array[counter]-array[(counter/2)]) / array[counter])*100);
                /* This was used to debug an issue thatwas found here on 1/19/2013 involving sorting.
                for(int x=0;x<counter+1;x++)
                {
                System.out.println(array[x]);
                }

                System.out.println ("max = " + array[counter]);
                System.out.println ("median = " + array[(counter)/2]);
                System.out.println ("result = " + result);
                System.out.println ("counter = " + counter);
                 */

                //System.out.println("counter " + counter + " " + filename);
                bw.write(" "+ result);
                bw.newLine();
                for(int x=0;x<=counter;x++)
                {
                    array[counter] = 0;
                }
                counter = 0;
            }
            else
            {   
                if(lineString.equals("flag"))
                {
                    while((lineString= br.readLine())!= null && lineString.equals("flag"))
                    {
                        // do nothing, we dont care.
                    }
                    if (lineString != null)
                    {
                        array[counter] = Double.parseDouble(lineString);

                        counter++;  
                    }
                }
                else
                {
                    if(lineString !=null)
                    {
                        array[counter] = Double.parseDouble(lineString);

                        counter++;
                    }
                }
            }
        }
        }
        bw.close();
        fw.close();
        preparecdf.graph(filename);
    }
}
