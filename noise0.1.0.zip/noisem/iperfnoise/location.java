package iperfnoise;
import java.io.*;
//this is used to pass text filenames
import java.util.Scanner;
//this is used for our regular expressions
import java.io.Console;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 *
 * on test case for parse, files: 1476 were reported by the program
 * 1477 files were actually present
 * 1475 lat/longitudes were printed
 * not all test cases data was Good iperf data.
 * May need to look into this further.

 * @author (your name) 
 * @version (a version number or a date)
 */
public class location
{
    public static void parse () throws Exception{

        FileReader fr = new FileReader("processor.txt");
        BufferedReader br = new BufferedReader(fr);
        FileWriter fw = new FileWriter("output\\location.txt");
        BufferedWriter bw = new BufferedWriter(fw);

        String filename = null;
        String lineString = null;
        int x = 0;
        Boolean failsafe = false;   //this ensures that only one data point is printed per test
        Boolean failed = false;     ///this checks if a test case failed
        System.out.println("Pulling location data:");
        

        while((filename= br.readLine())!= null){

            FileReader fr2 = new FileReader(filename);
            BufferedReader br2 = new BufferedReader(fr2);
            do
            {
                while ((lineString=br2.readLine()) != null && failed != true){
                    if (lineString.equals("no effective service") || lineString.equals("ERROR: CONNECT ERROR") || lineString.equals("ERROR: WRITE ERROR"))
                    {
                        //System.out.println(lineString);
                        x++;
                        failed = true;
                    }
                    
                }
                if (failed.equals(true))
                {         
                    filename= br.readLine();
                    failed = false;
                }
            } while (failed != false);
            
            br2.close();
            fr2.close();
            if (filename != null)
            {
                fr2 = new FileReader(filename);
                br2 = new BufferedReader(fr2);

                while((lineString= br2.readLine())!= null && failsafe != true){

                    Pattern pattern = 
                        Pattern.compile("(\\d{4}), \\d{2}/\\d{2}/\\d{4},.*");
                    Matcher matcher = pattern.matcher(lineString);
                    if(matcher .matches()){

                        failsafe = true;
                        bw.write(matcher.group(1));
                        bw.newLine();
                    }

                    //System.out.println ("iteration: " + x);
                }
                failsafe = false;

            }   
        }
        System.out.println("Failed tests: " + x);
        bw.close();
        fw.close();
        System.out.println("Done.");

    }

    public static void compile (String SP) throws Exception{
        FileReader fr = new FileReader("output\\location.txt");
        BufferedReader location = new BufferedReader(fr);
        FileReader fr2 = new FileReader("output\\noisedownloaddata.txt");
        BufferedReader download = new BufferedReader(fr2);
        FileReader fr3 = new FileReader("output\\noiseuploaddata.txt");
        BufferedReader upload = new BufferedReader(fr3);

        FileWriter fw = new FileWriter("output\\uploadlocationdata.csv");
        BufferedWriter bw = new BufferedWriter(fw);
        FileWriter fw2 = new FileWriter("output\\downloadlocationdata.csv");
        BufferedWriter bw2 = new BufferedWriter(fw2);
        
        FileReader fsp = new FileReader("condensed/sp.txt");
        BufferedReader bsp = new BufferedReader(fr);
        
        bw.write(SP + " Upload Noise Rates");
        bw.newLine();
        bw.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw.newLine();
        String data = null;
        int x = 1;
        while((data= location.readLine())!= null){
            bw.write(data + ",");

            data= upload.readLine();                                    
            bw.write(data + ",");

            data= upload.readLine();   
            bw.write(data + ",");

            data= upload.readLine();            
            bw.write(data + ",");

            data= upload.readLine();
            bw.write(data + ",");
            bw.newLine();

        }
        
        location.close();
        fr.close();
        
        //.................................................................
        
        fr = new FileReader("output\\location.txt");
        location = new BufferedReader(fr);
        
        bw2.write(SP + " Download Noise Rates");
        bw2.newLine();
        bw2.write("Locationd ID ,Test One,Test Two,Test Three,Test Four");
        bw2.newLine();
        data = null;
        x = 1;
        while((data= location.readLine())!= null){
            bw2.write(data + ",");

            data= download.readLine();                                    
            bw2.write(data + ",");

            data= download.readLine();   
            bw2.write(data + ",");

            data= download.readLine();            
            bw2.write(data + ",");

            data= download.readLine();
            bw2.write(data + ",");
            bw2.newLine();
            
        }
        
        location.close();
        
        upload.close();
        
        download.close();
        
        bw.close();
        bw2.close();
    }
}