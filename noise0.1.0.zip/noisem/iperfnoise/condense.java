package iperfnoise;
import java.io.*;
import java.util.Scanner;

/**
 * Write a description of class condense here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class condense
{
    public static void data() throws Exception
    { 
        Scanner s = new Scanner(new BufferedReader(new FileReader("processor.txt")));
        String filename = "nothing";
        FileWriter ffw = new FileWriter("condensed/uploaddata.txt");
        BufferedWriter fbw = new BufferedWriter(ffw);
        FileWriter f2fw = new FileWriter("condensed/downloaddata.txt");
        BufferedWriter f2bw = new BufferedWriter(f2fw);
        FileWriter pfr = new FileWriter("parsedfilenames.txt");
        BufferedWriter pbr = new BufferedWriter (pfr);
        pbr.write("uploaddata.txt");
        pbr.newLine();
        pbr.write("downloaddata.txt");
        pbr.newLine();
        pbr.close();
        while (s.hasNext()) {
            filename = s.next();

            FileReader fr = new FileReader("temp/upload" + filename);
            BufferedReader br = new BufferedReader(fr);
            FileReader dfr = new FileReader("temp/download" + filename);
            BufferedReader dbr = new BufferedReader(dfr);

            String lineString = null;
            
            while((lineString= br.readLine())!= null)
            {
                fbw.write(lineString);
                fbw.newLine();
                
            }
            while((lineString= dbr.readLine())!= null)
            {
                f2bw.write(lineString);
                f2bw.newLine();
            }
            
        }
        f2bw.close();
        f2fw.close();
        fbw.close();
        ffw.close();
    }
}
