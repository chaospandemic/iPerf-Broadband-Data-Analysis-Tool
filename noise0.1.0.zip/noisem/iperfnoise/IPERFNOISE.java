package iperfnoise;
/**
 * This is the main function for the Iperf noise calculation and graph plotting
 * 
 * @author Donald Willis 
 * @version 0.1.0
 */
import java.io.*;
public class IPERFNOISE
{
    public static void main(String[] args) throws Exception
    {
        System.out.println ("Starting the Iperf on Wireless Noise Plotter 0.1.0");
        System.out.println ("Author: Donald Willis\n\n");

        InputStreamReader varname = new InputStreamReader(System.in) ;
        BufferedReader provider = new BufferedReader(varname) ;
        FileWriter fw = new FileWriter ("condensed/sp.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        String SP = null;
        try                     {
            System.out.println("Please Enter The Service Provider To Be Processed: ");
            SP = provider.readLine();
            bw.write(SP);
        }
        catch (IOException err) {
            System.out.println("Error reading line");
        }
        bw.close();
        fw.close();

        String filename = null;
        int counter = 1;

        System.out.println ("Parsing files");
        Parse.process();
        System.out.println ("Done.");

        FileReader fr = new FileReader("parsedfilenames.txt");
        BufferedReader br = new BufferedReader(fr);

        while((filename= br.readLine())!= null){
            System.out.println ("Calculating noise for file " + counter);
            counter++;
            process.data(filename);
            System.out.println ("Done.");
        }
        location.parse();
        location.compile(SP);
    }
}
